<?php

return [
    'paginate' => [
        'perPage' => 20
    ]
];
