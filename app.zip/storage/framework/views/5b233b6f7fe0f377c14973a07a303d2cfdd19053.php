

<?php $__env->startSection('title', 'Roles'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Roles')); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('role.create')); ?>" class="btn bg-gradient-primary float-right">Add Role</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>







    <section class="content">
        <div class="container-fluid">
              <div id="page-content-wrapper">
        <div class="container-fluid pl-6">
          <div class="row">
            <!-- <div class="col-lg-12 d-flex justify-content-between">
              <a href="#" class="  boderradius " id="menu-toggle"><img src="../new/img/Folder 2.png" alt=""></a>
              <a href="#" class="btn btn-primary btn-lg addadmin " role="button" aria-pressed="true">+Add Admin</a>
            </div> -->
            
            <div class="col-lg-6 col-md-6  d-flex ">
                <a href="#" class="  boderradius " id="menu-toggle"><img src="../new/img/Folder 2.png" alt=""></a>
              </div>
              <div class="col-lg-6 col-md-6 col-sm-12  d-flex justify-content-end my-2 ">
                  <a href="../new/dashboard.html" class="btn btn-primary btn-lg addadmin " >+Add Admin</a>
  
              </div>
            <div class=" col-12 addadminhead">
                <div class="headernav mx-1 row">
                    <div class="col-lg-6 col-sm-12 col-md-2 p-4 ">
                        <h4 class="navhead">Admin</h4>
                    </div>
                    <div class="col-lg-6 col-md-10 col-sm-12 justify-content-end d-flex">
                        <form class="form-inline ">
                            <button class="btn btn-outline-success mr-3 my-sm-0" type="submit"><img src="../new/img/filter.png" alt=""> Filter</button>
                            <input class="form-control width-20 mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                        </form>
                    </div>
                
                </div>
              <div class="tablesection">
                <table class="table bg-white table-hover ">
                    <thead>
                      <tr>
                        <th scope="col">S.no</th>
                        <th scope="col">Name</th>
                        <th scope="col">phone</th>
                        <th scope="col">Email</th>
                        <th scope="col">Joined no</th>
                        <th scope="col">Left no</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <th scope="row">1</th>
                        <td>Guna</td>
                        <td>8934354243</td>
                        <td>guna@gmail.com</td>
                        <td>11-05-2019</td>
                        <td>21-07-2021</td>
                      </tr>
                      <tr>
                        <th scope="row">2</th>
                        <td>badu</td>
                        <td>8934354243</td>
                        <td>badu@gmail.com</td>
                        <td>21-03-2018</td>
                        <td>01-07-2021</td>

                      </tr>
                      <tr>
                        <th scope="row">3</th>
                        <td>harsha</td>
                        <td>8934354243</td>
                        <td>harsha@gmail.com</td>
                        <td>23-08-2020</td>
                        <td>03-03-2021</td>
                      </tr>
                    </tbody>
                  </table>
              </div>
                   
               
            </div>
            <div class=" col-12 d-flex justify-content-end">
                <nav aria-label="Page navigation page-lg">
                    <ul class="pagination justify-content-center">
                      <li class="page-item ">
                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                      </li>
                      <li class="page-item"><a class="page-link" href="#">1</a></li>
                      <li class="page-item"><a class="page-link" href="#">2</a></li>
                      <li class="page-item"><a class="page-link" href="#">3</a></li>
                      <li class="page-item">
                        <a class="page-link" href="#">Next</a>
                      </li>
                    </ul>
                  </nav>
            </div>
          
          </div>
        </div>
      </div>
            
            
            <div class="row">
                <div class="col-md-12">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has($message)): ?>
                        <div class="alert alert-<?php echo e($message); ?>">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo e(session($message)); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Role</h3>
                      <form class="float-right">
                          <input class="" type="text" name="search" >
                          <button class="btn btn-sm btn-info" type="submit">
                            search
                          </button>
                      </form>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered table-sm">
                            <thead>
                            <tr>
                                <th style="width: 50px">S.No</th>
                                <th>Role</th>
                                <th style="width: 200px">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $i = ($roles->currentpage()-1)* $roles->perpage() + 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e(ucwords($role->name)); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('role.edit',$role->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                            <form method="POST" action="<?php echo e(route('role.destroy', $role->id)); ?>"
                                                accept-charset="UTF-8"
                                                style="display: inline-block;"
                                                onsubmit="return confirm('Are you sure do you want to delete?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                                            </form>
                                            
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <th colspan="3" class="text-center">No Data Found...</th>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="float-right">
                            <?php echo $roles->links(); ?>

                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/role/index.blade.php ENDPATH**/ ?>