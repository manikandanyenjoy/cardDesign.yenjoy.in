<?php $__env->startSection('title', 'yarn'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('yarn - ') . $yarn->yarn_name); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('yarns.index')); ?>" class="btn bg-gradient-primary float-right">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">yarn</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('supplier Name')); ?></strong></td>
                                        <td><?php echo e($yarn->supplier); ?></td>

                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Yarn Denier')); ?></strong></td>
                                        <td><?php echo e($yarn->yarn_denier); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Shade No')); ?></strong></td>
                                        <td><?php echo e($yarn->shade_No); ?><?php echo e($yarn->shade_No_suffix); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Yarn Color')); ?></strong></td>
                                        
                                        <td><?php echo e($yarn->yarn_color); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Color Shade')); ?></strong></td>
                                        <td style="background-color: <?php echo e($yarn->color_shade); ?>;"></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Notes')); ?></strong></td>
                                        <td><?php echo e($yarn->notes); ?></td>
                                    </tr>
                                   
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/yarns/show.blade.php ENDPATH**/ ?>