<?php $__env->startSection('title', 'Role'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row justify-content-center">
        <div class="col-sm-7">
            <h1><?php echo e(__('Role')); ?></h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-7">

                <?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($editRole ? __('Edit Role') : __('Create Role')); ?></h3>
                        </div>
                        <form method="POST" action="<?php echo e($editRole ? route('role.update', $editRole->id) : route('role.store')); ?>" novalidate>
                            <?php if($editRole): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body row">
                                <div class="form-group col-12">
                                    <label for="role_name">Role Name</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="role_name" name="name" value="<?php echo e($editRole ? old('name',$editRole->name) : old('name')); ?>" placeholder="Role Name">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary btn-md col-3"><?php echo e($editRole ? __('Update') : __('Save')); ?></button>
                                <a href="<?php echo e(route('role.index')); ?>" class="btn btn-danger btn-md col-3"><?php echo e(__('Cancel')); ?></a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/role/create.blade.php ENDPATH**/ ?>