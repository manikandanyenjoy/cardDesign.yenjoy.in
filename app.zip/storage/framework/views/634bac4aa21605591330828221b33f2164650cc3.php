

<?php $__env->startSection('title', 'Sales Rep'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-1">
        <div class="offset-md-1 col-md-10">
            <h1 class="font-weight-bold float-left">
                <?php echo e(__('Sales Rep - ') . ucwords($salesrep->name)); ?>

            </h1>
            <div class="float-right">
                <a href="<?php echo e(route('staffs.edit',$salesrep->id)); ?>" class="btn bg-gradient-warning mr-2"><?php echo e(__('Edit')); ?></a>
                <a href="<?php echo e(route('salesreps.index')); ?>" class="btn bg-gradient-danger mr-2"><?php echo e(__('Back')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-1 col-md-10">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Sales rep Details</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('Full Name')); ?></strong></td>
                                        <td><?php echo e(ucwords($salesrep->name)); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Email')); ?></strong></td>
                                        <td><?php echo e($salesrep->email); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Phone')); ?></strong></td>
                                        <td><?php echo e($salesrep->phone); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Qualification')); ?></strong></td>
                                        <td><?php echo e(ucwords($salesrep->qualification)); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Role')); ?></strong></td>
                                        <td><?php echo e($salesrep->roleDetial ? ucwords($salesrep->roleDetial->name) : '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Blood Group')); ?></strong></td>
                                        <td><?php echo e($salesrep->blood_group ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Document ID')); ?></strong></td>
                                        <td><?php echo e($salesrep->documentID ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Document File')); ?></strong></td>
                                        <td>
                                            <?php if($salesrep->document_name): ?>
                                                <a href="<?php echo e($salesrep->document_name); ?>" download><i class="fas fa-download mr-2"></i>Download</a>
                                            <?php else: ?>
                                                No document files 
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Joined On')); ?></strong></td>
                                        <td><?php echo e($salesrep->joined_on); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Left On')); ?></strong></td>
                                        <td><?php echo e($salesrep->left_on ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Address')); ?></strong></td>
                                        <td><?php echo e($salesrep->address ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Status')); ?></strong></td>
                                        <td><?php echo e($salesrep->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/salesrep/show.blade.php ENDPATH**/ ?>