

<?php $__env->startSection('title', 'Vendors'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Vendors')); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('sellers.create')); ?>" class="btn bg-gradient-primary float-right"><?php echo e(__('Add Vendor')); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Vendors</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <thead>
                                <tr>
                                    <th style="width: 50px">#</th>
                                    <th>Fullname</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    
                                    <th style="width: 200px">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($index + $sellers->firstItem()); ?></td>
                                        <td><?php echo e(ucfirst($seller->full_name)); ?></td>
                                        <td><?php echo e($seller->email); ?></td>
                                        <td><?php echo e($seller->mobile_number); ?></td>
                                       
                                        <td>
                                            <a href="<?php echo e(route('sellers.show',$seller->id)); ?>" class="btn btn-sm btn-warning">View</a>
                                            <a href="<?php echo e(route('sellers.edit',$seller->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                            <form method="POST" action="<?php echo e(route('sellers.destroy', $seller->id)); ?>"
                                                  accept-charset="UTF-8"
                                                  style="display: inline-block;"
                                                  onsubmit="return confirm('Are you sure do you want to delete?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="7" class="text-center"><?php echo e(__('No data available')); ?></td>
                                    </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer clearfix">
                            <div class="float-right">
                                <?php echo $sellers->links(); ?>

                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/sellers/index.blade.php ENDPATH**/ ?>