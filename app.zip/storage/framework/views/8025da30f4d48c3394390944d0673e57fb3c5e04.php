<?php $__env->startSection('title', 'Loom Operator'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Loom Operator - ') . $loomoperator->name); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('loomoperators.index')); ?>" class="btn bg-gradient-primary float-right">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Loom Operator</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                        <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('First Name')); ?></strong></td>
                                        <td><?php echo e($loomoperator->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Email')); ?></strong></td>
                                        <td><?php echo e($loomoperator->email); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Phone')); ?></strong></td>
                                        <td><?php echo e($loomoperator->phone); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Qualification')); ?></strong></td>
                                        <td><?php echo e($loomoperator->qualification); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Blood Group')); ?></strong></td>
                                        <td><?php echo e($loomoperator->blood_group); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Joined On')); ?></strong></td>
                                        <td><?php echo e($loomoperator->joined_on); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Left On')); ?></strong></td>
                                        <td><?php echo e($loomoperator->left_on); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Document Number')); ?></strong></td>
                                        <td><?php echo e($loomoperator->documentID); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Document')); ?></strong></td>
                                        <td><a target="_blank" href="<?php echo e(env('APP_URL')); ?>/storage/staffs_document/<?php echo e($loomoperator->document_name); ?>">View Document</a></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Left On')); ?></strong></td>
                                        <td><?php echo e($loomoperator->left_on); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Address')); ?></strong></td>
                                        <td><?php echo e($loomoperator->address); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/loomoperator/show.blade.php ENDPATH**/ ?>