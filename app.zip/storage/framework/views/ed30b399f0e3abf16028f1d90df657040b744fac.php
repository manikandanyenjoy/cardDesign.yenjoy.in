

<?php $__env->startSection('title', 'Quality Checker'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-1">
        <div class="offset-md-1 col-md-10">
            <h1 class="font-weight-bold float-left">
                <?php echo e(__('Quality Checker - ') . ucwords($qualitychecker->name)); ?>

            </h1>
            <div class="float-right">
                <a href="<?php echo e(route('staffs.edit',$qualitychecker->id)); ?>" class="btn bg-gradient-warning mr-2"><?php echo e(__('Edit')); ?></a>
                <a href="<?php echo e(route('qualitycheckers.index')); ?>" class="btn bg-gradient-danger mr-2"><?php echo e(__('Back')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-1 col-md-10">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Quality Checker Details</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('Full Name')); ?></strong></td>
                                        <td><?php echo e(ucwords($qualitychecker->name)); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Email')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->email); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Phone')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->phone); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Qualification')); ?></strong></td>
                                        <td><?php echo e(ucwords($qualitychecker->qualification)); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Role')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->roleDetial ? ucwords($qualitychecker->roleDetial->name) : '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Blood Group')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->blood_group ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Document ID')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->documentID ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Document File')); ?></strong></td>
                                        <td>
                                            <?php if($qualitychecker->document_name): ?>
                                                <a href="<?php echo e($qualitychecker->document_name); ?>" download><i class="fas fa-download mr-2"></i>Download</a>
                                            <?php else: ?>
                                                No document files 
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Joined On')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->joined_on); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Left On')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->left_on ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Address')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->address ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Status')); ?></strong></td>
                                        <td><?php echo e($qualitychecker->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/qualitychecker/show.blade.php ENDPATH**/ ?>