

<?php $__env->startSection('title', 'warp'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('warp - ') . $warp->colour); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('warps.index')); ?>" class="btn bg-gradient-primary float-right">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">warp</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                <tr>
                                        <td><strong><?php echo e(__('Name')); ?></strong></td>
                                        <td><?php echo e($warp->name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Colour')); ?></strong></td>
                                        <td style="background-color: <?php echo e($warp->colour); ?>;"></td>
                                        
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ieemail/hilife.inevitabletech.email/resources/views/warps/show.blade.php ENDPATH**/ ?>