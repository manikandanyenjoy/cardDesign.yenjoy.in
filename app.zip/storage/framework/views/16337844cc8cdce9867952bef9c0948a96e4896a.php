

<?php if($editYarn): ?>
    <?php $__env->startSection('title', 'Edit Raw Material'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Create Raw Material'); ?>
<?php endif; ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row justify-content-center mb-1">
        <div class="col-md-8">
            <h1 class="float-left ml-2 font-weight-bold">
                <?php if($editYarn): ?>
                <?php echo e(__('Edit Raw Material - ') . ucfirst($editYarn->supplier)); ?>

                <?php else: ?>
                <?php echo e(__('Create Raw Material')); ?>

                <?php endif; ?>
            </h1>
            <div class="float-right">
                <?php if($editYarn): ?>
                    <a href="<?php echo e(route('yarns.show',$editYarn->id)); ?>" class="btn bg-gradient-success btn-md mr-2"><?php echo e(__('View')); ?></a>
                <?php endif; ?>
                <a href="<?php echo e(route('yarns.index')); ?>" class="btn bg-gradient-danger btn-md mr-2"><?php echo e(__('Back')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has($message)): ?>
                            <div class="alert alert-<?php echo e($message); ?>">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <?php echo e(session($message)); ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title"> <?php echo e($editYarn ? 'Edit Raw Material' : 'Create Raw Material'); ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <div class="card-body">
                            <form method="POST" action="<?php echo e($editYarn ? route('yarns.update', $editYarn->id) : route('yarns.store')); ?>" novalidate>
                                <?php echo csrf_field(); ?>
                                <?php if($editYarn): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
                                <div class="row">
                                    <div class="form-group col-6">
                                        <label for="supplier">Supplier Name</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['supplier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="supplier" name="supplier" value="<?php echo e($editYarn ? old('supplier',$editYarn->supplier) : old('supplier')); ?>" placeholder="Supplier Name">
                                        <?php $__errorArgs = ['supplier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group col-6">
                                        <label for="yarn_denier">Yarn Denier</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['yarn_denier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="yarn_denier" name="yarn_denier" value="<?php echo e($editYarn ? old('yarn_denier',$editYarn->yarn_denier) : old('yarn_denier')); ?>" placeholder="Yarn Denier">
                                        <?php $__errorArgs = ['yarn_denier'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="form-group col-6">
                                        <label for="shade_No">Shade No</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['shade_No'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="shade_No" name="shade_No" value="<?php echo e($editYarn ? old('shade_No',$editYarn->shade_No) : old('shade_No')); ?>" placeholder="Shade No">
                                        <?php $__errorArgs = ['shade_No'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group col-6">
                                        <label for="yarn_color">Yarn Color</label><!-- #ff0000 -->
                                        <input type="color" class="form-control <?php $__errorArgs = ['yarn_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="yarn_color" name="yarn_color" value="<?php echo e($editYarn ? old('yarn_color',$editYarn->yarn_color) : old('yarn_color')); ?>" placeholder="Yarn Color">
                                        <?php $__errorArgs = ['yarn_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                    <div class="form-group col-6">
                                        <label for="color_shade">Color Shade</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['color_shade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="color_shade" name="color_shade" value="<?php echo e($editYarn ? old('color_shade',$editYarn->color_shade) : old('color_shade')); ?>" placeholder="Color Shade">
                                        <?php $__errorArgs = ['color_shade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div> 

                                <div class="row">
                                    <div class="form-group col-6">
                                        <label for="notes">Notes</label>
                                        <textarea class="form-control <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="notes" name="notes"><?php echo e($editYarn ? old('notes',$editYarn->notes) : old('notes')); ?></textarea>
                                        <?php $__errorArgs = ['notes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-12">
                                        <button type="submit" class="btn btn-primary btn-md col-2 float-right"><?php echo e($editYarn ? 'Update' : 'Save'); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ieemail/hilife.inevitabletech.email/resources/views/yarns/create.blade.php ENDPATH**/ ?>