

<?php $__env->startSection('title', 'Customers'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Customers')); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('buyers.create')); ?>" class="btn bg-gradient-primary float-right"><?php echo e(__('Add Customer')); ?></a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Customers</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <thead>
                                <tr>
                                    <th style="width: 50px">S.No</th>
                                    <th>Company Name</th>
                                    <th>FullName</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th style="width: 200px">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $i = ($buyers->currentpage()-1)* $buyers->perpage() + 1; ?>

                                    <?php $__empty_1 = true; $__currentLoopData = $buyers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($i++); ?></td>
                                            <td><?php echo e(ucwords($buyer->company_name)); ?></td>
                                            <td><?php echo e(ucfirst($buyer->full_name)); ?></td>
                                            <td><?php echo e($buyer->email); ?></td>
                                            <td><?php echo e($buyer->mobile_number); ?></td>
                                        
                                            <td>
                                                <a href="<?php echo e(route('buyers.show',$buyer->id)); ?>" class="btn btn-sm btn-warning">View</a>
                                                <a href="<?php echo e(route('buyers.edit',$buyer->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                                <form method="POST" action="<?php echo e(route('buyers.destroy', $buyer->id)); ?>"
                                                    accept-charset="UTF-8"
                                                    style="display: inline-block;"
                                                    onsubmit="return confirm('Are you sure do you want to delete?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" class="text-center"><?php echo e(__('No data Found...')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer clearfix">
                            <div class="float-right">
                                <?php echo $buyers->links(); ?>

                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/buyers/index.blade.php ENDPATH**/ ?>