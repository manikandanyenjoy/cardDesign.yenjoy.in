

<?php $__env->startSection('title', 'fold'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Fold - ') . ucwords($fold->type_of_fold)); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('folds.index')); ?>" class="btn bg-gradient-primary float-right">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">fold</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('Type of Fold')); ?></strong></td>
                                        <td><?php echo e($fold->type_of_fold); ?></td>

                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Image')); ?></strong></td>
                                        <td><img src="<?php echo e($fold->image); ?>" alt="image" width="200" height="200"></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Minimum mm	')); ?></strong></td>
                                        <td><?php echo e($fold->minimum_mm); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Notes')); ?></strong></td>
                                        
                                        <td><?php echo e($fold->notes); ?></td>
                                    </tr>
                                    
                                   
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/folds/show.blade.php ENDPATH**/ ?>