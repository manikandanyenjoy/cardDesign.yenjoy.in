

<?php $__env->startSection('title', 'Edit Woven'); ?>

<style type="text/css">
    .face{
        position: absolute;
        height: 0px;
        width: 0px;
        background-color: transparent;;
        border: 4px solid rgba(10,10,10,0.5);
    }
    .object-fit-container {
        border: 2px solid;
        padding: 10px;
    
    height: 230px; /*any size*/
    }

    .object-fit-cover {
    width: auto;
    height: 100%;
    display: block;
    margin-left: auto;
    margin-right: auto;
    object-fit: cover; /*magic*/
    }
</style>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Edit Woven - ') . $woven->lable); ?></h1>
        </div>

        <div class="row mb-2">
            <div class="col-sm-12 pr-4 d-flex justify-content-end">
                <a href="<?php echo e(route('woven.edit',$woven->id)); ?>" class="btn col-1 bg-gradient-primary mr-3">Edit</a>
                <a href="<?php echo e(route('woven.index')); ?>" class="btn col-1 bg-gradient-danger">Back</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has($message)): ?>
                            <div class="alert alert-<?php echo e($message); ?>">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <?php echo e(session($message)); ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- /.card -->
                    <div class="card card-primary" >
                        <!-- card-header -->
                        <div class="card-header">
                            <h3 class="card-title">Edit Design Card</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form method="POST" action="<?php echo e(route('woven.update', $woven->id)); ?>" novalidate>
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="card-body row"  style=" overflow: scroll;margin: 15px;" >
                                <div class="table_forms">
                                    <div class="table_wrp table-responsive">
                                        <table style="width: 1000px; margin: auto;" class="table table-bordered">
                                            <tbody>
                                                <tr>
                                                    <td style="padding:0;">
                                                        <table width="100%">
                                                            <tr>
                                                                <td width="150px"><strong>Customer</strong></td>
                                                                <td width=300px>
                                                                    <select class="form-control col-6 <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="customer" name="customer_id">
                                                                        <option value="">Please Select Customer</option>
                                                                        <?php $__currentLoopData = $data['customerMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <option value="<?php echo e($customer['id']); ?>" <?php echo e(old('customer_id') == $customer['id'] ? 'selected' : ($customer['id'] == $editdesignCard->customer_id ? 'selected' : '')); ?>><?php echo e(ucfirst($customer['first_name'])); ?> </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                                <td width="150px" ><strong>Date</strong></td>
                                                                    <td width="150px" >
                                                                    <input type="date" class="form-control col-6 <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="date" name="date" value="<?php echo e($editdesignCard->date); ?>" placeholder="">
                                                                    <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                            </tr>

                                                            <tr>
                                                                <td width="150px"><strong>Label </strong></td>
                                                                <td width=300px>
                                                                    <input type="text" class="form-control col-6 <?php $__errorArgs = ['lable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="label" name="lable" value="<?php echo e($editdesignCard->lable); ?>" placeholder="label">
                                                                    <?php $__errorArgs = ['lable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                                <td colspan="2"></td>
                                                            </tr>
                                                        </table>
                                                        <!-- design details  -->
                                                        <table width="100%">
                                                            <tr>
                                                                <td width="150px"><strong>Designer</strong></td>
                                                                <td>
                                                                    <select class="form-control col-4 <?php $__errorArgs = ['designer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="designer" name="designer_id">
                                                                        <option value="">Please Select Designer</option>
                                                                        <?php $__currentLoopData = $data['designerMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <option value="<?php echo e($designer['id']); ?>" <?php echo e(old('designer_id') == $designer['id'] ? 'selected' : ($designer['id'] == $editdesignCard->designer_id ? 'selected' : '')); ?>><?php echo e(ucfirst($designer['name'])); ?> </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['designer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                                <td><strong>Design No</strong></td>
                                                                <td>
                                                                    <input type="text" class="form-control col-9 <?php $__errorArgs = ['design_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="design_no" name="design_number" value="<?php echo e(old('design_number', $editdesignCard->design_number)); ?>" placeholder="DH546">
                                                                    <?php $__errorArgs = ['design_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="150px"><strong>Sales Rep</strong></td>
                                                                <td>
                                                                    <select class="form-control col-4 <?php $__errorArgs = ['salesrep_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sales_rep" name="salesrep_id">
                                                                        <option value="">Please Select Sales Rep</option>
                                                                        <?php $__currentLoopData = $data['salesrepMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesrep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <option value="<?php echo e($salesrep['id']); ?>" <?php echo e(old('salesrep_id') == $salesrep['id'] ? 'selected' : ($salesrep['id'] == $editdesignCard->salesrep_id ? 'selected' : '')); ?>><?php echo e(ucfirst($salesrep['name'])); ?> </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['salesrep_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                                <td><strong>Quality</strong></td>
                                                                <td><input type="text" class="form-control col-9" placeholder="Enter the value" value=""></td>
                                                            </tr>
                                                            <tr>
                                                                <td width="150px"><strong>Sample Weaver</strong></td>
                                                                <td>
                                                                    <select class="form-control col-4 <?php $__errorArgs = ['weaver_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="sample_weaver" name="weaver[]" multiple>
                                                                        <option value="">Please Sample</option>
                                                                        <?php $__currentLoopData = $data['designerMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <option value="<?php echo e($designer['id']); ?>" <?php echo e(in_array($designer['id'], $editdesignCard->weaver_id) ? 'selected' : ''); ?>><?php echo e($designer['name']); ?> </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['weaver'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                                <td width="150px"><strong>Warp</strong></td>
                                                                <td>
                                                                    <select class="form-control col-9 <?php $__errorArgs = ['warp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="warp" name="warps_id">
                                                                        <option value="">Please Select Warp</option>
                                                                        <?php $__currentLoopData = $data['warpMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <option value="<?php echo e($warp['id']); ?>" <?php echo e(old('warps_id') == $warp['id'] ? 'selected' : ($warp['id'] == $editdesignCard->warps_id ? 'selected' : '')); ?>><?php echo e(ucfirst($warp['name'])); ?> </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['warps_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td><strong>Picks/cm</strong></td>
                                                                <td>
                                                                    <div class="d-flex"> 
                                                                        <input type="text" class="form-control col-4 <?php $__errorArgs = ['pick'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pick" name="picks" value="<?php echo e(old('picks',$editdesignCard->picks)); ?>" placeholder="Pick"> <span>/cm</span>
                                                                        <?php $__errorArgs = ['picks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </td>
                                                                <td><strong>Total Pick</strong></td>
                                                                <td>
                                                                    <input type="text" name="total_picks" class="form-control col-9 <?php $__errorArgs = ['total_picks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('total_picks',$editdesignCard->total_picks)); ?>" placeholder="Enter the value"> 
                                                                    <?php $__errorArgs = ['total_picks'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                        <!-- design details  -->
                                                        <table width="100%">
                                                            <tr>
                                                                <th>Looms</th>
                                                                <?php $__currentLoopData = $data['loomMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $looms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <th><?php echo e(ucfirst($looms['loom_name'])); ?></th>
                                                                    <input type="hidden" value="<?php echo e($looms['loom_name']); ?>" name="looms[]">
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tr>
                                                            <tr>
                                                                <th>Total Repeats</th>
                                                                <?php $__currentLoopData = $editdesignCard->total_repet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_repet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <td><input type="text" class="form-control col-7" name="total_repet[]" value="<?php echo e($total_repet); ?>" placeholder="Enter the value"></td>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tr>
                                                        </table>
                                                        <table width="100%">
                                                            <tr>
                                                                <td width="150px"><strong>Wastage</strong></td>
                                                                <td>
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="radio" value="yes" name="wastage" <?php echo e(old('wastage') == "yes" ? 'checked' : ($editdesignCard->wastage == "yes" ? 'checked' : '')); ?>>
                                                                        <label class="form-check-label">YES</label>
                                                                        <input class="form-check-input" type="radio" value="no" name="wastage" <?php echo e(old('wastage') == "no" ? 'checked' : ($editdesignCard->wastage == "no" ? 'checked' : '')); ?> style="margin-left:35px;">
                                                                        <label class="form-check-label" style="margin-left:55px;">NO</label>
                                                                    </div>
                                                                    <?php $__errorArgs = ['wastage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                                <td><strong>Finishings</strong></td>
                                                                <td>
                                                                    <select class="form-control col-6 <?php $__errorArgs = ['finishing_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="finishing_id">
                                                                        <option value="">Please Select Warp</option>
                                                                        <?php $__currentLoopData = $data['finishingMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finishing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <option value="<?php echo e($finishing['id']); ?>" <?php echo e(old('finishing_id') == $finishing['id'] ? 'selected' : ($finishing['id'] == $editdesignCard->finishing_id ? 'selected' : '')); ?>><?php echo e(ucfirst($finishing['machine'])); ?> </option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    <?php $__errorArgs = ['finishing_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                        <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="150px">
                                                                    <strong>Width mm</strong>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <input type="text" class="form-control col-6 <?php $__errorArgs = ['width'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="width" value="<?php echo e(old('width',$editdesignCard->width)); ?>" placeholder="Enter the value">
                                                                        <?php $__errorArgs = ['finishing_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <strong>Length mm</strong>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <input type="text" class="form-control col-6 <?php $__errorArgs = ['length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="length" value="<?php echo e(old('length',$editdesignCard->length)); ?>" placeholder="Enter the value">
                                                                        <?php $__errorArgs = ['length'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="150px">
                                                                    <strong>Total Area /Sq mm</strong>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <input type="text" class="form-control col-6 <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="total_cost" value="<?php echo e(old('total_cost',$editdesignCard->total_cost)); ?>" placeholder="Enter the value">
                                                                        <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <strong>cost in roll</strong>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <input type="text" class="form-control col-6 <?php $__errorArgs = ['cost_in_roll'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="cost_in_roll" value="<?php echo e(old('cost_in_roll',$editdesignCard->cost_in_roll)); ?>" placeholder="Enter the value">
                                                                        <?php $__errorArgs = ['cost_in_roll'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td width="150px">
                                                                    <strong>Sq Inch </strong>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <input type="text" class="form-control col-6 <?php $__errorArgs = ['sq_inch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="sq_inch" value="<?php echo e(old('sq_inch',$editdesignCard->sq_inch)); ?>" placeholder="Enter the value">
                                                                        <?php $__errorArgs = ['sq_inch'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <strong>Cost /sq inch</strong>
                                                                </td>
                                                                <td>
                                                                    <div>
                                                                        <input type="text" class="form-control col-6 <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Enter the value">
                                                                        <?php $__errorArgs = ['total_cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        </table>
                                                    </td>

                                                    <td style="padding:0;" width="300px">
                                                        <div class="form-group ">
                                                            <div class="object-fit-container">   
                                                                <img class="object-fit-cover"  id="result" />
                                                            </div>
                                                            <label for="file">Design Image</label>
                                                            <input type="file" class=" <?php $__errorArgs = ['crap_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="file" name="crap_image" value="<?php echo e(old('crap_image')); ?>">
                                                            <?php $__errorArgs = ['crap_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div> 
                                                        <div><img width="100%" src="./img.jpg" alt=""></div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="padding:0;" colspan="2">
                                                        <table width="100%">
                                                            <tr>
                                                                <th>Add ons</th>
                                                                <th>Basic</th>
                                                                <th>Cut fold</th>
                                                                <th>Diecut</th>
                                                                <th>Nonwoven</th>
                                                                <th>Iron on back</th>
                                                                <th>Extras</th>
                                                                <th>TOTAL</th>
                                                                <th>Offered </th>
                                                            </tr>
                                                            <tr>
                                                                <th style="width:300px;">Cost</th>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['0']) ?  $editdesignCard->add_on_cast['0'] : ''); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['1']) ?  $editdesignCard->add_on_cast['1'] : ''); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['2']) ?  $editdesignCard->add_on_cast['2'] : ''); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['3']) ?  $editdesignCard->add_on_cast['3'] : ''); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['4']) ?  $editdesignCard->add_on_cast['4'] : ''); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['5']) ?  $editdesignCard->add_on_cast['5'] : ''); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['6']) ?  $editdesignCard->add_on_cast['6'] : ''); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="form-control" name="add_on_cast[]" value="<?php echo e(isset($editdesignCard->add_on_cast['7']) ?  $editdesignCard->add_on_cast['7'] : ''); ?>" placeholder="Enter the value"></td>
                                                           
                                                            </tr>
                                                        </table>
                                                        <!-- needle table  -->
                                                        <table width="100%">
                                                            <tr>
                                                                <th>Needle No/Pantone</th>
                                                                <th>Color</th>
                                                                <th>Color Shade</th>
                                                                <th>Denier</th>
                                                                <th>A</th>
                                                                <th>B</th>
                                                                <th>C</th>
                                                                <th>D</th>
                                                                <th>E</th>
                                                            </tr>
                                                            <?php $__empty_1 = true; $__currentLoopData = $editdesignCard->needle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $needle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <tr>
                                                                    <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[needle_no_pantone]" value="<?php echo e($needle['needle_no_pantone']); ?>" placeholder="Enter the value"></td>
                                                                    <td><input type="color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[color]" value="<?php echo e($needle['color']); ?>" placeholder="Enter the value"></td>
                                                                    <td><input type="color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[color_shade]" value="<?php echo e($needle['color_shade']); ?>"></td>
                                                                    <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[denier]"  value="<?php echo e($needle['denier']); ?>" placeholder="Enter the value"></td>
                                                                    <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[a]" value="<?php echo e($needle['a']); ?>" placeholder="Enter the value"></td>
                                                                    <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[b]" value="<?php echo e($needle['b']); ?>" placeholder="Enter the value"></td>
                                                                    <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[c]" value="<?php echo e($needle['c']); ?>" placeholder="Enter the value"></td>
                                                                    <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[d]" value="<?php echo e($needle['d']); ?>" placeholder="Enter the value"></td>
                                                                    <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="needle[e]" value="<?php echo e($needle['e']); ?>" placeholder="Enter the value"></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                <tr colspan="9">
                                                                    <td>No Needle pantone found...</td>
                                                                </tr>
                                                            <?php endif; ?>
                                                        </table>
                                                        <!-- needle table  -->
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary float-right">Update</button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/woven/edit.blade.php ENDPATH**/ ?>