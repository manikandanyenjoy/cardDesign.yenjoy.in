

<?php $__env->startSection('title', 'Design Card'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Design Card')); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('woven.create')); ?>" class="btn bg-gradient-primary float-right">Add Design Card</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has($message)): ?>
                        <div class="alert alert-<?php echo e($message); ?>">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo e(session($message)); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Design Card</h3>
                      	<form class="float-right">
                          <input class="" type="text" name="search" >
                          <button class="btn btn-sm btn-info" type="submit">
                            search
                          </button>
                      </form>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered table-sm">
                            <thead>
                            <tr>
                                <th style="width: 50px">S.No</th>
                                <th>Customer</th>
                                <th>Label</th>
                                <th>Design No</th>
                                <th>Sales Representative</th>
                                <th>Created On</th>
                                <th style="width: 200px">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $i = ($wovens->currentpage()-1)* $wovens->perpage() + 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $wovens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $woven): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($woven->customerDetail ? ucwords($woven->customerDetail->company_name) : '-'); ?></td>
                                        <td><?php echo e($woven->label ? ucwords($woven->label) : '-'); ?></td>
                                        <td><?php echo e(isset($woven->main_label['design_no']) ? $woven->main_label['design_no'] : '-'); ?></td>
                                        <td><?php echo e($woven->salesRepDetail ? ucwords($woven->salesRepDetail->name) : '-'); ?></td>
                                        <td><?php echo e($woven->date ? $woven->date : '-'); ?></td>
                                        
                                        <td>
                                            <a href="<?php echo e(route('woven.show',$woven->id)); ?>" class="btn btn-sm btn-warning">View</a>
                                            
                                            <a href="<?php echo e(route('woven.edit',$woven->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                            <form method="POST" action="<?php echo e(route('woven.destroy', $woven->id)); ?>"
                                                accept-charset="UTF-8"
                                                style="display: inline-block;"
                                                onsubmit="return confirm('Are you sure do you want to delete?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                                            </form>
                                            
                                        </td>
                                    </tr>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <th colspan="7" class="text-center">No Data Found...</th>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="float-right">
                            <?php echo $wovens->links(); ?>

                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/woven/index.blade.php ENDPATH**/ ?>