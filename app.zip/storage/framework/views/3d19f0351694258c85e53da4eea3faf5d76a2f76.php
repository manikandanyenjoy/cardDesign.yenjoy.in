

<?php if($editink): ?>
    <?php $__env->startSection('title', 'Edit Raw Material'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Create Raw Material'); ?>
<?php endif; ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row justify-content-center mb-1">
        <div class="col-md-8">
            <h1 class="float-left ml-2 font-weight-bold">
                <?php if($editink): ?>
                <?php echo e(__('Edit Raw Material - ') . ucfirst($editink->supplier)); ?>

                <?php else: ?>
                <?php echo e(__('Create Raw Material')); ?>

                <?php endif; ?>
            </h1>
            <div class="float-right">
                <?php if($editink): ?>
                    <a href="<?php echo e(route('ink.show',$editink->id)); ?>" class="btn bg-gradient-success btn-md mr-2"><?php echo e(__('View')); ?></a>
                <?php endif; ?>
                <a href="<?php echo e(route('ink.index')); ?>" class="btn bg-gradient-danger btn-md mr-2"><?php echo e(__('Back')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has($message)): ?>
                            <div class="alert alert-<?php echo e($message); ?>">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <?php echo e(session($message)); ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title"> <?php echo e($editink ? 'Edit Ink' : 'Create Ink '); ?></h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <div class="card-body">
                            <form method="POST" action="<?php echo e($editink ? route('ink.update', $editink->id) : route('ink.store')); ?>" novalidate>
                                <?php echo csrf_field(); ?>
                                <?php if($editink): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
                                <div class="row">
                                    <div class="form-group col-6">
                                        <label for="color">ink Color</label><!-- #ff0000 -->
                                        <input type="color" class="form-control <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="color" name="color" value="<?php echo e($editink ? old('color',$editink->color) : old('color')); ?>" placeholder="ink Color">
                                        <?php $__errorArgs = ['color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    
                                
                                    <div class="form-group col-6">
                                        <label for="shade_no">Shade No</label>
                                        <input type="text" class="form-control <?php $__errorArgs = ['shade_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="shade_no" name="shade_no" value="<?php echo e($editink ? old('shade_no',$editink->shade_no) : old('shade_no')); ?>" placeholder="Shade No">
                                        <?php $__errorArgs = ['shade_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    </div>
                                    
                                <div class="row">
                                    <div class="form-group col-12">
                                        <label for="make">Make</label>
                                        <textarea class="form-control <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="make" name="make"><?php echo e($editink ? old('make',$editink->make) : old('make')); ?></textarea>
                                        <?php $__errorArgs = ['make'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="form-group col-12">
                                        <button type="submit" class="btn btn-primary btn-md col-2 float-right"><?php echo e($editink ? 'Update' : 'Save'); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/ink/create.blade.php ENDPATH**/ ?>