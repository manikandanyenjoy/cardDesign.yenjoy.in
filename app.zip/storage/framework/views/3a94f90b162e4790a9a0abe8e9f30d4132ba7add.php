<?php $__env->startSection('title', 'Loom Operators'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Loom Operators')); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('staffs.create')); ?>" class="btn bg-gradient-primary float-right">Add Loom Operators</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has($message)): ?>
                        <div class="alert alert-<?php echo e($message); ?>">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo e(session($message)); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">Loom Operators</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered table-sm">
                            <thead>
                            <tr>
                                <th style="width: 50px">#</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Joined On</th>
                                <th>Left On</th>
                                <th style="width: 200px">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $loomoperators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $loomoperator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($loomoperator->name); ?></td>
                                    <td><?php echo e($loomoperator->email); ?></td>
                                    <td><?php echo e($loomoperator->phone); ?></td>
                                    <td><?php echo e($loomoperator->joined_on); ?></td>
                                    <td><?php echo e($loomoperator->left_on); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('loomoperators.show',$loomoperator->id)); ?>" class="btn btn-sm btn-warning">View</a>
                                        <?php if(!$loomoperator->deleted_at): ?>
                                        <a href="<?php echo e(route('staffs.edit',$loomoperator->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                        <form method="POST" action="<?php echo e(route('loomoperators.destroy', $loomoperator->id)); ?>"
                                              accept-charset="UTF-8"
                                              style="display: inline-block;"
                                              onsubmit="return confirm('Are you sure do you want to delete?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="float-right">
                            <?php echo $loomoperators->links(); ?>

                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/loomoperator/index.blade.php ENDPATH**/ ?>