

<?php if($editdesignCard): ?>
    <?php $__env->startSection('title', 'Edit Design Card'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Create Design Card'); ?>
<?php endif; ?>

<style type="text/css">
    .face{
        position: absolute;
        height: 0px;
        width: 0px;
        background-color: transparent;;
        border: 4px solid rgba(10,10,10,0.5);
    }
    .object-fit-container {
        overflow:hidden;
        border: 2px solid;
        padding: 10px;
    
    height: 230px; /*any size*/
    }

    .object-fit-cover {
    width: auto;
    height: 100%;
    display: block;
    margin-left: auto;
    margin-right: auto;
    object-fit: cover; /*magic*/
    }
    tr input {

        width:70px
    }
    /* .label_names
    {
        border:none !important;
        color:#000;
        font-weight:bold;
    } */
</style>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1 class="pl-2"><?php echo e($editdesignCard ? "Edit Woven - ".$editdesignCard->label : "Create Woven"); ?></h1>
        </div>

        <div class="col-sm-6 pr-4 d-flex justify-content-end">
            <?php if($editdesignCard): ?>
                <a href="<?php echo e(route('woven.show',$editdesignCard->id)); ?>" class="btn col-2 bg-gradient-primary mr-3">View</a>
            <?php endif; ?>
            <a href="<?php echo e(route('woven.index')); ?>" class="btn col-2 bg-gradient-danger">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Session::has($message)): ?>
                            <div class="alert alert-<?php echo e($message); ?>">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <?php echo e(session($message)); ?>

                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- /.card -->
                    <div class="card card-primary" >
                        <!-- card-header -->
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($editdesignCard ? 'Edit' : 'Create'); ?> Design Card</h3>
                        </div>
                        <!-- /.card-header -->
                        <!-- form start -->
                        <form method="POST" action="<?php echo e($editdesignCard ? route('woven.update', $editdesignCard->id) : route('woven.store')); ?>" enctype="multipart/form-data" novalidate>
                            <?php echo csrf_field(); ?>
                            <?php if($editdesignCard): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-9">
                                        <div class="table-responsive">
                                            <table class="table table-bordered text-nowrap">
                                                <tr>
                                                    <th>Customer</th>
                                                    <td>
                                                        <select class="form-control <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="customer_id">
                                                            <option value="">Select Customer</option>
                                                            <?php $__currentLoopData = $data['customerMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                <?php if($editdesignCard): ?>
                                                                    <option value="<?php echo e($customer['id']); ?>" <?php echo e(old('customer_id') == $customer['id'] ? 'selected' : ($customer['id'] == $editdesignCard->customer_id ? 'selected' : '')); ?>><?php echo e(ucfirst($customer['company_name'])); ?> </option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($customer['id']); ?>" <?php echo e(old('customer_id') == $customer['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($customer['company_name'])); ?> </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                        <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                            <div class="invalid-feedback">
                                                                <?php echo e($message); ?>

                                                            </div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </td>
                                                    <th>Label</th>
                                                    <td><input type="text" name="label" value="<?php echo e($editdesignCard ? old('label',$editdesignCard->label) : old('label')); ?>" class="form-control"></td>
                                                    <th>Date</th>
                                                    <td><input type="date" name="date" value="<?php echo e($editdesignCard ? old('date',$editdesignCard->date) : old('date')); ?>" class="form-control"></td>
                                                </tr>

                                                <tr>
                                                    <th>Designer</th>
                                                    <td>
                                                        <select class="form-control" name="designer_id">
                                                            <option value="">Select Designer</option>
                                                            <?php $__currentLoopData = $data['designerMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                <?php if($editdesignCard): ?>
                                                                    <option value="<?php echo e($designer['id']); ?>" <?php echo e(old('designer_id') == $designer['id'] ? 'selected' : ($designer['id'] == $editdesignCard->designer_id ? 'selected' : '')); ?>><?php echo e(ucfirst($designer['name'])); ?> </option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($designer['id']); ?>" <?php echo e(old('designer_id') == $designer['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($designer['name'])); ?> </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <th>Sales Rep</th>
                                                    <td>
                                                        <select class="form-control" name="salesrep_id">
                                                            <option value="">Select Sales Rep</option>
                                                            <?php $__currentLoopData = $data['salesrepMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesrep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                <?php if($editdesignCard): ?>
                                                                    <option value="<?php echo e($salesrep['id']); ?>" <?php echo e(old('salesrep_id') == $salesrep['id'] ? 'selected' : ($salesrep['id'] == $editdesignCard->salesrep_id ? 'selected' : '')); ?>><?php echo e(ucfirst($salesrep['name'])); ?> </option>
                                                                    <?php else: ?>
                                                                    <option value="<?php echo e($salesrep['id']); ?>" <?php echo e(old('salesrep_id') == $salesrep['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($salesrep['name'])); ?> </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <th>Weaver</th>
                                                    <td width="150px">
                                                        <div class="form-group row mx-2">
                                                            <select style="width: 50%;"  class="form-control" name="weaver[]">
                                                                <option value="">Select</option>
                                                                <?php $__currentLoopData = $data['loomOperator']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                    <?php if($editdesignCard): ?>
                                                                        <option value="<?php echo e($loom['id']); ?>" <?php echo e(old('weaver.0') == $loom['id'] ? 'selected' : ($loom['id'] == (isset($editdesignCard->weaver[0]) ? $editdesignCard->weaver[0] : '')? 'selected' : '')); ?>><?php echo e(ucfirst($loom['name'])); ?> </option>
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($loom['id']); ?>" <?php echo e(old('weaver.0') == $loom['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($loom['name'])); ?> </option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <select style="width: 50%;" class="form-control" name="weaver[]">
                                                                <option value="">Select</option>
                                                                <?php $__currentLoopData = $data['loomOperator']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                    <?php if($editdesignCard): ?>
                                                                        <option value="<?php echo e($loom['id']); ?>" <?php echo e(old('weaver.1') == $loom['id'] ? 'selected' : ($loom['id'] == (isset($editdesignCard->weaver[1]) ? $editdesignCard->weaver[1] : '')? 'selected' : '')); ?>><?php echo e(ucfirst($loom['name'])); ?> </option>
                                                                        <?php else: ?>
                                                                        <option value="<?php echo e($loom['id']); ?>" <?php echo e(old('weaver.1') == $loom['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($loom['name'])); ?> </option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                    </td>
                                                </tr>

                                                <tr>
                                                    <th>Warp</th>
                                                    <td>
                                                        <select name="warps_id" class="form-control">
                                                            <option value="">Select Warp</option>
                                                            <?php $__currentLoopData = $data['warpMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                <?php if($editdesignCard): ?>
                                                                    <option value="<?php echo e($warp['id']); ?>" <?php echo e(old('warps_id') == $warp['id'] ? 'selected' : ($warp['id'] == $editdesignCard->warps_id ? 'selected' : '')); ?>><?php echo e(ucfirst($warp['name'])); ?> </option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($warp['id']); ?>" <?php echo e(old('warps_id') == $warp['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($warp['name'])); ?> </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <th>Folds</th>
                                                    <td>
                                                         <select name="finishing" class="form-control">
                                                            <option value="">Select Folds</option>
                                                            <?php $__currentLoopData = $data['foldMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fold): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                <?php if($editdesignCard): ?>
                                                                    <option value="<?php echo e($fold['id']); ?>" <?php echo e(old('finishing') == $fold['id'] ? 'selected' : ($warp['id'] == $editdesignCard->finishing ? 'selected' : '')); ?>><?php echo e(ucfirst($fold['type_of_fold'])); ?> </option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($fold['id']); ?>" <?php echo e(old('finishing') == $fold['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($fold['type_of_fold'])); ?> </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <th>Notes</th>
                                                    <td>
                                                       <textarea name="description" cols="30" rows="3" class="form-control">
                                                           <?php echo e($editdesignCard ? old('finishing',$editdesignCard->finishing) : old('finishing')); ?>

                                                       </textarea>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th>Category</th>
                                                    <td>
                                                         <select name="category" class="form-control">
                                                            <option value="">Select Category</option>
                                                            <?php $__currentLoopData = $data['categoryMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                <?php if($editdesignCard): ?>
                                                                    <option value="<?php echo e($category['id']); ?>" <?php echo e(old('category') == $category['id'] ? 'selected' : ($category['id'] == $editdesignCard->category ? 'selected' : '')); ?>><?php echo e(ucfirst($category['category_name'])); ?> </option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($category['id']); ?>" <?php echo e(old('category') == $category['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($category['category_name'])); ?> </option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </td>
                                                    <td colspan="5"></td>
                                                </tr>
                                            </table>
                                                 
                                            <div class="row">
                                                <div class="col">
                                                    <table class="table table-bordered text-nowrap">
                                                        <tr>
                                                            <th></th>
                                                            <th>
                                                                <div class="custom-control custom-checkbox">
                                                                    <input type="checkbox" class="custom-control-input" id="main_label" checked disabled>
                                                                    <label class="custom-control-label" for="main_label">Main Label</label>
                                                                </div>
                                                            </th>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Design No</th>
                                                            <td width="200px"><input type="text" name="main_label[design_no]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['design_no']) ? $editdesignCard->main_label['design_no'] : ''); ?>" class="form-control"></td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <th width="200px">Quality</th>
                                                            <td width="200px">
                                                                <select name="main_label[quality]" class="form-control">
                                                                    <option value="">Select Quality</option>
                                                                    <?php $__currentLoopData = $data['wovenQuality']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                        <?php if($editdesignCard): ?>
                                                                            <option value="<?php echo e($quality['id']); ?>" <?php echo e(old('finishing') == $quality['id'] ? 'selected' : ($quality['id'] == ($editdesignCard && isset($editdesignCard->main_label['quality']) ? $editdesignCard->main_label['quality'] : '')? 'selected' : '')); ?>><?php echo e(ucfirst($quality['quality'])); ?> </option>
                                                                        <?php else: ?>
                                                                            <option value="<?php echo e($quality['id']); ?>" <?php echo e(old('finishing') == $quality['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($quality['quality'])); ?> </option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            <th width="200px">Picks/Cm</th>
                                                            <td width="200px"><input type="text" name="main_label[picks]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['picks']) ? $editdesignCard->main_label['picks'] : ''); ?>" class="form-control"></td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Total Picks</th>
                                                            <td width="200px"><input type="text" name="main_label[total_picks]" id="main_total_picks" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['total_picks']) ? $editdesignCard->main_label['total_picks'] : ''); ?>" class="form-control"></td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Total Repeat</th>
                                                            <td width="200px">
                                                                <div class="form-group row">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="text" name="main_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['total_repeat'][0]) ? old('main_label.total_repeat.0',$editdesignCard->main_label['total_repeat'][0]) : old('main_label.total_repeat.0')); ?>" class="form-control col" id="main_repeat_first_input">
                                                                        <input type="text" name="main_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['total_repeat'][1]) ? old('main_label.total_repeat.1',$editdesignCard->main_label['total_repeat'][1]) : old('main_label.total_repeat.1')); ?>" class="form-control col" id="main_repeat_second_input">
                                                                        <input type="text" name="main_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['total_repeat'][2]) ? old('main_label.total_repeat.2',$editdesignCard->main_label['total_repeat'][2]) : old('main_label.total_repeat.2')); ?>" class="form-control col" id="main_repeat_last_input">
                                                                    <?php else: ?>
                                                                        <input type="text" name="main_label[total_repeat][]" value="<?php echo e(old('main_label.total_repeat.0')); ?>" id="main_repeat_first_input" class="form-control col">
                                                                        <input type="text" name="main_label[total_repeat][]" value="<?php echo e(old('main_label.total_repeat.1')); ?>" id="main_repeat_second_input" class="form-control col">
                                                                        <input type="text" name="main_label[total_repeat][]" value="<?php echo e(old('main_label.total_repeat.2')); ?>" id="main_repeat_last_input" class="form-control col">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Total Label Per Hours</th>
                                                            <td width="200px">
                                                                <div class="form-group row">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="text" id="main_labelhrs_first" name="main_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['total_labour_hours'][0]) ? old('main_label.total_labour_hours.0', $editdesignCard->main_label['total_labour_hours'][0]) : old('main_label.total_labour_hours.0')); ?>" class="form-control col">
                                                                        <input type="text" id="main_labelhrs_second" name="main_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['total_labour_hours'][1]) ? old('main_label.total_labour_hours.1', $editdesignCard->main_label['total_labour_hours'][1]) : old('main_label.total_labour_hours.1')); ?>" class="form-control col">
                                                                        <input type="text" id="main_labelhrs_third" name="main_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['total_labour_hours'][2]) ? old('main_label.total_labour_hours.2', $editdesignCard->main_label['total_labour_hours'][2]) : old('main_label.total_labour_hours.2')); ?>" class="form-control col">
                                                                    <?php else: ?>
                                                                        <input type="text" id="main_labelhrs_first" name="main_label[total_labour_hours][]" value="<?php echo e(old('main_label.total_labour_hours.0')); ?>" class="form-control col">
                                                                        <input type="text" id="main_labelhrs_second" name="main_label[total_labour_hours][]" value="<?php echo e(old('main_label.total_labour_hours.1')); ?>" class="form-control col">
                                                                        <input type="text" id="main_labelhrs_third" name="main_label[total_labour_hours][]" value="<?php echo e(old('main_label.total_labour_hours.2')); ?>" class="form-control col">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Wastage</th>
                                                            <td width="200px">
                                                                <div class="form-group d-flex">
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="radio" value="yes" name="main_label[wastage]" <?php echo e($editdesignCard && isset($editdesignCard->main_label['wastage']) ? $editdesignCard->main_label['wastage'] == 'yes' ? 'checked' : '' : ''); ?>>
                                                                        <label class="form-check-label ml-4">Yes</label>
                                                                    </div>
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="radio" value="no" name="main_label[wastage]" <?php echo e($editdesignCard && isset($editdesignCard->main_label['wastage']) ? $editdesignCard->main_label['wastage'] == 'no' ? 'checked' : '' : 'checked'); ?>>
                                                                        <label class="form-check-label ml-4">No</label>
                                                                    </div>
                                                                </div>                                                                
                                                            </td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Width</th>
                                                            <td width="200px"><input type="text" id="main_width_input" name="main_label[width]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['width']) ? $editdesignCard->main_label['width'] : ''); ?>" class="form-control"></td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Length</th>
                                                            <td width="200px"><input type="text" id="main_length_input" name="main_label[length]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['length']) ? $editdesignCard->main_label['length'] : ''); ?>" class="form-control"></td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Sq mm</th>
                                                            <td width="200px"><input type="text" id="main_sq_mm_input" name="main_label[sq_mm]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['sq_mm']) ? $editdesignCard->main_label['sq_mm'] : ''); ?>" class="form-control"></td>
                                                        </tr>

                                                        <tr>
                                                            <th width="200px">Sq inch</th>
                                                            <td width="200px"><input type="text" id="main_sq_inch_input" name="main_label[sq_inch]" value="<?php echo e($editdesignCard && isset($editdesignCard->main_label['sq_inch']) ? $editdesignCard->main_label['sq_inch'] : ''); ?>" class="form-control"></td>
                                                        </tr>
                                                    </table>
                                                </div>

                                                <div class="col">
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <th>
                                                                <div class="custom-control custom-checkbox">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="checkbox" name="tab_label[label]"  value="<?php echo e((isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'yes') ? 'yes' : 'no') : 'no')); ?>" <?php echo e((isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'yes') ? 'checked' : '') : '')); ?> class="custom-control-input" id="tab_label">
                                                                    <?php else: ?>
                                                                        <input type="checkbox" name="tab_label[label]"  value="<?php echo e(old('tab_label.label') == 'yes' ? 'yes' : 'no'); ?>" <?php echo e(old('tab_label.label') == 'yes' ? 'checked' : ''); ?> class="custom-control-input" id="tab_label">
                                                                    <?php endif; ?>
                                                                    <label class="custom-control-label" for="tab_label">Tab Label</label>
                                                                </div>
                                                            </th>
                                                        </tr>
                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="tab_label[design_no]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['design_no']) ? old('tab_label.design_no',$editdesignCard->tab_label['design_no']) : old('tab_label.design_no')); ?>" class="form-control"></td>
                                                        </tr>
                                                        
                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <select name="tab_label[quality]" class="form-control">
                                                                    <option value="">Select Quality</option>
                                                                    <?php $__currentLoopData = $data['wovenQuality']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                        <?php if($editdesignCard): ?>
                                                                            <option value="<?php echo e($quality['id']); ?>" <?php echo e(old('finishing') == $quality['id'] ? 'selected' : ($quality['id'] == ($editdesignCard && isset($editdesignCard->tab_label['quality']) ? $editdesignCard->tab_label['quality'] : '')? 'selected' : '')); ?>><?php echo e(ucfirst($quality['quality'])); ?> </option>
                                                                        <?php else: ?>
                                                                            <option value="<?php echo e($quality['id']); ?>" <?php echo e(old('finishing') == $quality['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($quality['quality'])); ?> </option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        
                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                          <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="tab_label[picks]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['picks']) ? old('tab_label.picks', $editdesignCard->tab_label['picks']) : old('tab_label.picks')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" id="tab_total_picks" name="tab_label[total_picks]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['total_picks']) ? old('tab_label.total_picks', $editdesignCard->tab_label['total_picks']) : old('tab_label.total_picks')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <div class="form-group row">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="text" id="tab_repeat_first_input" name="tab_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['total_repeat'][0]) ? old('tab_label.total_repeat.0',$editdesignCard->tab_label['total_repeat'][0]) : ''); ?>" class="form-control col">
                                                                        <input type="text" id="tab_repeat_second_input" name="tab_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['total_repeat'][1]) ? old('tab_label.total_repeat.1',$editdesignCard->tab_label['total_repeat'][1]) : ''); ?>" class="form-control col">
                                                                        <input type="text" id="tab_repeat_last_input" name="tab_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['total_repeat'][2]) ? old('tab_label.total_repeat.2',$editdesignCard->tab_label['total_repeat'][2]) : ''); ?>" class="form-control col">
                                                                    <?php else: ?>
                                                                        <input type="text" id="tab_repeat_first_input" name="tab_label[total_repeat][]" value="<?php echo e(old('tab_label.total_repeat.0')); ?>" class="form-control col">
                                                                        <input type="text" id="tab_repeat_second_input" name="tab_label[total_repeat][]" value="<?php echo e(old('tab_label.total_repeat.1')); ?>" class="form-control col">
                                                                        <input type="text" id="tab_repeat_last_input" name="tab_label[total_repeat][]" value="<?php echo e(old('tab_label.total_repeat.2')); ?>" class="form-control col">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <div class="form-group row">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="text" id="tab_labelhrs_first" name="tab_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['total_labour_hours'][0]) ? old('tab_label.total_labour_hours.0', $editdesignCard->tab_label['total_labour_hours'][0]) : old('tab_label.total_labour_hours.0')); ?>" class="form-control col">
                                                                        <input type="text" id="tab_labelhrs_second" name="tab_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['total_labour_hours'][1]) ? old('tab_label.total_labour_hours.1', $editdesignCard->tab_label['total_labour_hours'][1]) : old('tab_label.total_labour_hours.1')); ?>" class="form-control col">
                                                                        <input type="text" id="tab_labelhrs_third" name="tab_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['total_labour_hours'][2]) ? old('tab_label.total_labour_hours.2', $editdesignCard->tab_label['total_labour_hours'][2]) : old('tab_label.total_labour_hours.2')); ?>" class="form-control col">
                                                                    <?php else: ?>
                                                                        <input type="text" id="tab_labelhrs_first" name="tab_label[total_labour_hours][]" value="<?php echo e(old('tab_label.total_labour_hours.0')); ?>" class="form-control col">
                                                                        <input type="text" id="tab_labelhrs_second" name="tab_label[total_labour_hours][]" value="<?php echo e(old('tab_label.total_labour_hours.1')); ?>" class="form-control col">
                                                                        <input type="text" id="tab_labelhrs_third" name="tab_label[total_labour_hours][]" value="<?php echo e(old('tab_label.total_labour_hours.2')); ?>" class="form-control col">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <div class="form-group d-flex">
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="radio" value="yes" name="tab_label[wastage]" <?php echo e($editdesignCard && isset($editdesignCard->tab_label['wastage']) ? $editdesignCard->tab_label['wastage'] == 'yes' ? 'checked' : '' : ''); ?>>
                                                                        <label class="form-check-label ml-4">Yes</label>
                                                                    </div>
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="radio" value="no" name="tab_label[wastage]" <?php echo e($editdesignCard && isset($editdesignCard->tab_label['wastage']) ? $editdesignCard->tab_label['wastage'] == 'no' ? 'checked' : '' : 'checked'); ?>>
                                                                        <label class="form-check-label ml-4">No</label>
                                                                    </div>
                                                                </div>  
                                                            </td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <input type="text" name="tab_label[width]" id="tab_width_input" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['width']) ? old('tab_label.width', $editdesignCard->tab_label['width']) :  old('tab_label.width')); ?>" class="form-control">
                                                            </td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="tab_label[length]" id="tab_length_input" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['length']) ? old('tab_label.length', $editdesignCard->tab_label['length']) : old('tab_label.length')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="tab_label[sq_mm]" id="tab_sq_mm_input" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['sq_mm']) ? old('tab_label.sq_mm', $editdesignCard->tab_label['sq_mm']) : old('tab_label.sq_mm')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="tab_label_input <?php echo e(isset($editdesignCard->tab_label['label']) ? (($editdesignCard->tab_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="tab_label_input <?php if(old('tab_label.label') == 'no'): ?> d-none <?php elseif(old('tab_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="tab_label[sq_inch]" id="tab_sq_inch_input" value="<?php echo e($editdesignCard && isset($editdesignCard->tab_label['sq_inch']) ? old('tab_label.sq_inch', $editdesignCard->tab_label['sq_inch']) : old('tab_label.sq_inch')); ?>" class="form-control"></td>
                                                        </tr>
                                                    </table>
                                                </div>

                                                <div class="col">
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <th>
                                                                <div class="custom-control custom-checkbox">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="checkbox" name="size_label[label]"  value="<?php echo e((isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'yes') ? 'yes' : 'no') : 'no')); ?>" <?php echo e((isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'yes') ? 'checked' : '') : '')); ?> class="custom-control-input" id="size_label">
                                                                    <?php else: ?>
                                                                        <input type="checkbox" name="size_label[label]"  value="<?php echo e(old('size_label.label') == 'yes' ? 'yes' : 'no'); ?>" <?php echo e(old('size_label.label') == 'yes' ? 'checked' : ''); ?> class="custom-control-input" id="size_label">
                                                                    <?php endif; ?>
                                                                    <label class="custom-control-label" for="size_label">Size Label</label>
                                                                </div>
                                                            </th>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="size_label[design_no]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['design_no']) ? old('size_label.design_no',$editdesignCard->size_label['design_no']) : old('size_label.design_no')); ?>" class="form-control"></td>
                                                        </tr>
                                                        
                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <select name="size_label[quality]" class="form-control">
                                                                    <option value="">Select Quality</option>
                                                                    <?php $__currentLoopData = $data['wovenQuality']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                        <?php if($editdesignCard): ?>
                                                                            <option value="<?php echo e($quality['id']); ?>" <?php echo e(old('finishing') == $quality['id'] ? 'selected' : ($quality['id'] == ($editdesignCard && isset($editdesignCard->size_label['quality']) ? $editdesignCard->size_label['quality'] : '')? 'selected' : '')); ?>><?php echo e(ucfirst($quality['quality'])); ?> </option>
                                                                        <?php else: ?>
                                                                            <option value="<?php echo e($quality['id']); ?>" <?php echo e(old('finishing') == $quality['id'] ? 'selected' : ''); ?>><?php echo e(ucfirst($quality['quality'])); ?> </option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>
                                                        </tr>
                                                        
                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="size_label[picks]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['picks']) ? old('size_label.picks',$editdesignCard->size_label['picks']) : old('size_label.picks')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" id="size_total_picks" name="size_label[total_picks]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['total_picks']) ? old('size_label.total_picks',$editdesignCard->size_label['total_picks']) : old('size_label.total_picks')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <div class="form-group row">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="text" id="size_repeat_first_input" name="size_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['total_repeat'][0]) ? old('size_label.total_repeat.0',$editdesignCard->size_label['total_repeat'][0]) : old('size_label.total_repeat.0')); ?>" class="form-control col">
                                                                        <input type="text" id="size_repeat_second_input" name="size_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['total_repeat'][1]) ? old('size_label.total_repeat.1',$editdesignCard->size_label['total_repeat'][1]) : old('size_label.total_repeat.1')); ?>" class="form-control col">
                                                                        <input type="text" id="size_repeat_last_input" name="size_label[total_repeat][]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['total_repeat'][2]) ? old('size_label.total_repeat.2',$editdesignCard->size_label['total_repeat'][2]) : old('size_label.total_repeat.2')); ?>" class="form-control col">
                                                                    <?php else: ?>
                                                                        <input type="text" id="size_repeat_first_input" name="size_label[total_repeat][]" value="<?php echo e(old('size_label.total_repeat.0')); ?>" class="form-control col">
                                                                        <input type="text" id="size_repeat_second_input" name="size_label[total_repeat][]" value="<?php echo e(old('size_label.total_repeat.1')); ?>" class="form-control col">
                                                                        <input type="text" id="size_repeat_last_input" name="size_label[total_repeat][]" value="<?php echo e(old('size_label.total_repeat.2')); ?>" class="form-control col">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <div class="form-group row">
                                                                    <?php if($editdesignCard): ?>
                                                                        <input type="text" id="size_labelhrs_first" name="size_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['total_labour_hours'][0]) ? old('size_label.total_labour_hours.0',$editdesignCard->size_label['total_labour_hours'][0]) : old('size_label.total_labour_hours.0')); ?>" class="form-control col">
                                                                        <input type="text" id="size_labelhrs_second" name="size_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['total_labour_hours'][1]) ? old('size_label.total_labour_hours.1',$editdesignCard->size_label['total_labour_hours'][1]) : old('size_label.total_labour_hours.1')); ?>" class="form-control col">
                                                                        <input type="text" id="size_labelhrs_third" name="size_label[total_labour_hours][]" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['total_labour_hours'][2]) ? old('size_label.total_labour_hours.2',$editdesignCard->size_label['total_labour_hours'][2]) : old('size_label.total_labour_hours.2')); ?>" class="form-control col">
                                                                    <?php else: ?>
                                                                        <input type="text" id="size_labelhrs_first" name="size_label[total_labour_hours][]" value="<?php echo e(old('size_label.total_labour_hours.0')); ?>" class="form-control col">
                                                                        <input type="text" id="size_labelhrs_second" name="size_label[total_labour_hours][]" value="<?php echo e(old('size_label.total_labour_hours.1')); ?>" class="form-control col">
                                                                        <input type="text" id="size_labelhrs_third" name="size_label[total_labour_hours][]" value="<?php echo e(old('size_label.total_labour_hours.2')); ?>" class="form-control col">
                                                                    <?php endif; ?>
                                                                </div>
                                                            </td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px">
                                                                <div class="form-group d-flex">
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="radio" value="yes" name="size_label[wastage]" <?php echo e($editdesignCard && isset($editdesignCard->size_label['wastage']) ? $editdesignCard->size_label['wastage'] == 'yes' ? 'checked' : '' : ''); ?>>
                                                                        <label class="form-check-label ml-4">Yes</label>
                                                                    </div>
                                                                    <div class="form-check">
                                                                        <input class="form-check-input" type="radio" value="no" name="size_label[wastage]" <?php echo e($editdesignCard && isset($editdesignCard->size_label['wastage']) ? $editdesignCard->size_label['wastage'] == 'no' ? 'checked' : '' : 'checked'); ?>>
                                                                        <label class="form-check-label ml-4">No</label>
                                                                    </div>
                                                                </div>                                                                
                                                            </td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="size_label[width]" id="size_width_input" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['width']) ? old('size_label.width', $editdesignCard->size_label['width']) : old('size_label.width')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="size_label[length]" id="size_length_input" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['length']) ? old('size_label.length', $editdesignCard->size_label['length']) : old('size_label.length')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="size_label[sq_mm]" id="size_sq_mm_input" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['sq_mm']) ? old('size_label.sq_mm', $editdesignCard->size_label['sq_mm']) : old('size_label.sq_mm')); ?>" class="form-control"></td>
                                                        </tr>

                                                        <?php if($editdesignCard): ?>
                                                            <tr class="size_label_input <?php echo e(isset($editdesignCard->size_label['label']) ? (($editdesignCard->size_label['label'] == 'no') ? 'd-none' : '') : 'd-none'); ?>">
                                                        <?php else: ?>
                                                            <tr class="size_label_input <?php if(old('size_label.label') == 'no'): ?> d-none <?php elseif(old('size_label.label') == 'yes'): ?>) <?php else: ?> d-none <?php endif; ?>">
                                                        <?php endif; ?>
                                                            <td width="200px"><input type="text" name="size_label[sq_inch]" id="size_sq_inch_input" value="<?php echo e($editdesignCard && isset($editdesignCard->size_label['sq_inch']) ? old('size_label.sq_inch', $editdesignCard->size_label['sq_inch']) : old('size_label.sq_inch')); ?>" class="form-control"></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        
                                            <table class="table table-bordered text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Add on</th>
                                                        <th>Basic</th>
                                                        <th>Cut fold</th>	
                                                        <th>Diecut</th>	
                                                        <th>Nonwoven</th>		
                                                        <th>Iron on back</th>
                                                        <th>Extras</th>
                                                        <th>Total</th>
                                                        <th>Offered</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr id="main_table_row">
                                                        <th>Main</th>
                                                        <td><input type="text" name="main_cost[basic]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['basic']) ? $editdesignCard->add_on_main_cost['basic'] : ''); ?>" class="form-controls main_txt_cal"></td>
                                                        <td><input type="text" name="main_cost[cut_fold]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['cut_fold']) ? $editdesignCard->add_on_main_cost['cut_fold'] : ''); ?>" class="form-controls main_txt_cal"></td>
                                                        <td><input type="text" name="main_cost[diecut]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['diecut']) ? $editdesignCard->add_on_main_cost['diecut'] : ''); ?>" class="form-controls main_txt_cal"></td>
                                                        <td><input type="text" name="main_cost[nonwoven]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['nonwoven']) ? $editdesignCard->add_on_main_cost['nonwoven'] : ''); ?>" class="form-controls main_txt_cal"></td>
                                                        <td><input type="text" name="main_cost[iron_on_back]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['iron_on_back']) ? $editdesignCard->add_on_main_cost['iron_on_back'] : ''); ?>" class="form-controls main_txt_cal"></td>
                                                        <td><input type="text" name="main_cost[extra]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['extra']) ? $editdesignCard->add_on_main_cost['extra'] : ''); ?>" class="form-controls main_txt_cal"></td>
                                                        <td><input type="text" name="main_cost[total]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['total']) ? $editdesignCard->add_on_main_cost['total'] : ''); ?>" class="form-controls" readonly id="main_total_value"></td>
                                                        <td><input type="text" name="main_cost[offered]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_main_cost['offered']) ? $editdesignCard->add_on_main_cost['offered'] : ''); ?>" class="form-controls"></td>
                                                    </tr>

                                                    <tr id="tab_table_row">
                                                        <th>Tab</th>
                                                        <td><input type="text" name="tab_cost[basic]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['basic']) ? $editdesignCard->add_on_tab_cost['basic'] : ''); ?>" class="form-controls tab_txt_cal"></td>
                                                        <td><input type="text" name="tab_cost[cut_fold]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['cut_fold']) ? $editdesignCard->add_on_tab_cost['cut_fold'] : ''); ?>" class="form-controls tab_txt_cal"></td>
                                                        <td><input type="text" name="tab_cost[diecut]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['diecut']) ? $editdesignCard->add_on_tab_cost['diecut'] : ''); ?>" class="form-controls tab_txt_cal"></td>
                                                        <td><input type="text" name="tab_cost[nonwoven]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['nonwoven']) ? $editdesignCard->add_on_tab_cost['nonwoven'] : ''); ?>" class="form-controls tab_txt_cal"></td>
                                                        <td><input type="text" name="tab_cost[iron_on_back]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['iron_on_back']) ? $editdesignCard->add_on_tab_cost['iron_on_back'] : ''); ?>" class="form-controls tab_txt_cal"></td>
                                                        <td><input type="text" name="tab_cost[extra]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['extra']) ? $editdesignCard->add_on_tab_cost['extra'] : ''); ?>" class="form-controls tab_txt_cal"></td>
                                                        <td><input type="text" name="tab_cost[total]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['total']) ? $editdesignCard->add_on_tab_cost['total'] : ''); ?>" class="form-controls" readonly id="tab_total_value"></td>
                                                        <td><input type="text" name="tab_cost[offered]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_tab_cost['offered']) ? $editdesignCard->add_on_tab_cost['offered'] : ''); ?>" class="form-controls"></td>
                                                    </tr>

                                                    <tr id="size_table_row">
                                                        <th>Size</th>
                                                        <td><input type="text" name="size_cost[basic]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['basic']) ? $editdesignCard->add_on_size_cost['basic'] : ''); ?>" class="form-controls size_txt_cal"></td>
                                                        <td><input type="text" name="size_cost[cut_fold]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['cut_fold']) ? $editdesignCard->add_on_size_cost['cut_fold'] : ''); ?>" class="form-controls size_txt_cal"></td>
                                                        <td><input type="text" name="size_cost[diecut]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['diecut']) ? $editdesignCard->add_on_size_cost['diecut'] : ''); ?>" class="form-controls size_txt_cal"></td>
                                                        <td><input type="text" name="size_cost[nonwoven]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['nonwoven']) ? $editdesignCard->add_on_size_cost['nonwoven'] : ''); ?>" class="form-controls size_txt_cal"></td>
                                                        <td><input type="text" name="size_cost[iron_on_back]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['iron_on_back']) ? $editdesignCard->add_on_size_cost['iron_on_back'] : ''); ?>" class="form-controls size_txt_cal"></td>
                                                        <td><input type="text" name="size_cost[extra]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['extra']) ? $editdesignCard->add_on_size_cost['extra'] : ''); ?>" class="form-controls size_txt_cal"></td>
                                                        <td><input type="text" name="size_cost[total]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['total']) ? $editdesignCard->add_on_size_cost['total'] : ''); ?>" class="form-controls" readonly id="size_total_value"></td>
                                                        <td><input type="text" name="size_cost[offered]" value="<?php echo e($editdesignCard && isset($editdesignCard->add_on_size_cost['offered']) ? $editdesignCard->add_on_size_cost['offered'] : ''); ?>" class="form-controls"></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            <div class="row d-flex align-items-center">
                                                <h5 class="ml-2 pr-3 font-weight-bold">Main</h5>
                                                <button type="button" class="btn btn-success font-weight-bold m-2 text-white" id="addMainRow">Add Row</button>
                                            </div>
                                            <table class="table table-bordered text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Needle No</th>
                                                        <th>Pantone</th>
                                                        <th>Color</th>
                                                        <th>Shade</th>
                                                        <th>Denier</th>
                                                        <th>A</th>
                                                        <th>B</th>
                                                        <th>C</th>
                                                        <th>D</th>
                                                        <th>E</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="add_main_new_row">
                                                    <?php if($editdesignCard): ?>
                                                        <?php $__empty_1 = true; $__currentLoopData = $editdesignCard->main_needle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $needleIndex => $mainNeedle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr class="inputMainFormRow">
                                                                <td><input type="text" readonly class="main_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[<?php echo e($needleIndex); ?>][needle_no]" value="<?php echo e($mainNeedle['needle_no']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[<?php echo e($needleIndex); ?>][pantone]" value="<?php echo e($mainNeedle['pantone']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="color" class="main_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[<?php echo e($needleIndex); ?>][color]" value="<?php echo e($mainNeedle['color']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="main_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="main_needle[<?php echo e($needleIndex); ?>][color_shade]" value="<?php echo e($mainNeedle['color_shade']); ?>"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[<?php echo e($needleIndex); ?>][denier]"  value="<?php echo e($mainNeedle['denier']); ?>" placeholder="Enter the value"></td>
                                                                <td>
                                                                    <select name="main_needle[<?php echo e($needleIndex); ?>][a]" class="main_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select A</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" <?php echo e($yarn['id'] == $mainNeedle['a'] ? 'selected' : ''); ?> data-main_color="<?php echo e($yarn['yarn_color']); ?>" data-main_shade="<?php echo e($yarn['color_shade']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="main_needle[<?php echo e($needleIndex); ?>][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select B</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" <?php echo e($yarn['id'] == $mainNeedle['b'] ? 'selected' : ''); ?> ><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="main_needle[<?php echo e($needleIndex); ?>][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select C</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" <?php echo e($yarn['id'] == $mainNeedle['c'] ? 'selected' : ''); ?> ><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="main_needle[<?php echo e($needleIndex); ?>][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select D</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" <?php echo e($yarn['id'] == $mainNeedle['d'] ? 'selected' : ''); ?> ><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="main_needle[<?php echo e($needleIndex); ?>][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select E</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" <?php echo e($yarn['id'] == $mainNeedle['e'] ? 'selected' : ''); ?> ><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td><button id="removeMainRow" class="btn btn-danger" type="button">remove</button></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr class="inputMainFormRow">
                                                                <td><input type="text" readonly class="main_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][needle_no]" value="1" placeholder="Enter the value"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][pantone]" value="" placeholder="Enter the value"></td>
                                                                <td><input type="color" class="main_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][color]" value="" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="main_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][color_shade]" value=""></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][denier]"  value="" placeholder="Enter the value"></td>
                                                                <td>
                                                                    <select name="main_needle[0][a]" class="main_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select A</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" data-main_color="<?php echo e($yarn['yarn_color']); ?>" data-main_shade="<?php echo e($yarn['color_shade']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="main_needle[0][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select B</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="main_needle[0][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select C</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="main_needle[0][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select D</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" ><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="main_needle[0][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select E</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($yarn['id']); ?>" ><?php echo e($yarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td><button id="removeMainRow" class="btn btn-danger" type="button">remove</button></td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <tr class="inputMainFormRow">
                                                            <td><input type="text" readonly class="main_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][needle_no]" value="1" placeholder="Enter the value"></td>
                                                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][pantone]" value="" placeholder="Enter the value"></td>
                                                            <td><input type="color" class="main_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="main_needle[0][color]" value="" placeholder="Enter the value"></td>
                                                            <td><input type="text" class="main_color_shade" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="main_needle[0][color_shade]" value=""></td>
                                                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[0][denier]"  value="" placeholder="Enter the value"></td>
                                                            <td>
                                                                <select name="main_needle[0][a]" class="main_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select A</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($yarn['id']); ?>" data-main_color="<?php echo e($yarn['yarn_color']); ?>" data-main_shade="<?php echo e($yarn['color_shade']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="main_needle[0][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select B</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="main_needle[0][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select C</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="main_needle[0][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select D</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="main_needle[0][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select E</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>
                                                           
                                                            <td><button id="removeMainRow" class="btn btn-danger" type="button">remove</button></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>

                                            <div class="row d-flex align-items-center">
                                                <h5 class="ml-2 pr-4 font-weight-bold">Tab</h5>
                                                <button type="button" class="btn btn-success font-weight-bold m-2 text-white" id="addTabRow">Add Row</button>
                                            </div>
                                            <table class="table table-bordered text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Needle No</th>
                                                        <th>Pantone</th>
                                                        <th>Color</th>
                                                        <th>Shade</th>
                                                        <th>Denier</th>
                                                        <th>A</th>
                                                        <th>B</th>
                                                        <th>C</th>
                                                        <th>D</th>
                                                        <th>E</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="add_tab_new_row">
                                                    <?php if($editdesignCard): ?>
                                                        <?php $__empty_1 = true; $__currentLoopData = $editdesignCard->tab_needle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabIndex => $tabNeedle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr class="inputTabFormRow">
                                                                <td><input type="text" readonly class="tab_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[<?php echo e($tabIndex); ?>][needle_no]" value="<?php echo e($tabNeedle['needle_no']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[<?php echo e($tabIndex); ?>][pantone]" value="<?php echo e($tabNeedle['pantone']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="color" class="tab_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[<?php echo e($tabIndex); ?>][color]" value="<?php echo e($tabNeedle['color']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="tab_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="tab_needle[<?php echo e($tabIndex); ?>][color_shade]" value="<?php echo e($tabNeedle['color_shade']); ?>"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[<?php echo e($tabIndex); ?>][denier]"  value="<?php echo e($tabNeedle['denier']); ?>" placeholder="Enter the value"></td>
                                                                <td>
                                                                    <select name="tab_needle[<?php echo e($tabIndex); ?>][a]" class="tab_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select A</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>" <?php echo e($tabYarn['id'] == $tabNeedle['a'] ? 'selected' : ''); ?> data-tab_color="<?php echo e($tabYarn['yarn_color']); ?>" data-tab_shade="<?php echo e($tabYarn['color_shade']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="tab_needle[<?php echo e($tabIndex); ?>][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select B</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>" <?php echo e($tabYarn['id'] == $tabNeedle['b'] ? 'selected' : ''); ?> ><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="tab_needle[<?php echo e($tabIndex); ?>][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select C</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>" <?php echo e($tabYarn['id'] == $tabNeedle['c'] ? 'selected' : ''); ?> ><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="tab_needle[<?php echo e($tabIndex); ?>][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select D</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>" <?php echo e($tabYarn['id'] == $tabNeedle['d'] ? 'selected' : ''); ?> ><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="tab_needle[<?php echo e($tabIndex); ?>][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select E</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>" <?php echo e($tabYarn['id'] == $tabNeedle['e'] ? 'selected' : ''); ?> ><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td><button id="removeTabRow" class="btn btn-danger" type="button">remove</button></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr class="inputTabFormRow">
                                                                <td><input type="text" readonly class="tab_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][needle_no]" value="1" placeholder="Enter the value"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][pantone]" value="" placeholder="Enter the value"></td>
                                                                <td><input type="color" class="tab_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][color]" value="" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="tab_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][color_shade]" value=""></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][denier]"  value="" placeholder="Enter the value"></td>
                                                                <td>
                                                                    <select name="tab_needle[0][a]" class="tab_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select A</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>" data-tab_color="<?php echo e($tabYarn['yarn_color']); ?>" data-tab_shade="<?php echo e($tabYarn['color_shade']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="tab_needle[0][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select B</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="tab_needle[0][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select C</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="tab_needle[0][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select D</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="tab_needle[0][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select E</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td><button id="removeTabRow" class="btn btn-danger" type="button">remove</button></td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <tr class="inputTabFormRow">
                                                            <td><input type="text" readonly class="tab_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][needle_no]" value="1" placeholder="Enter the value"></td>
                                                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][pantone]" value="" placeholder="Enter the value"></td>
                                                            <td><input type="color" class="tab_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="tab_needle[0][color]" value="" placeholder="Enter the value"></td>
                                                            <td><input type="text" class="tab_color_shade" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="tab_needle[0][color_shade]" value=""></td>
                                                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[0][denier]"  value="" placeholder="Enter the value"></td>
                                                            <td>
                                                                <select name="tab_needle[0][a]" class="tab_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select A</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($tabYarn['id']); ?>" data-tab_color="<?php echo e($tabYarn['yarn_color']); ?>" data-tab_shade="<?php echo e($tabYarn['color_shade']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="tab_needle[0][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select B</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="tab_needle[0][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select C</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="tab_needle[0][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select D</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="tab_needle[0][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select E</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($tabYarn['id']); ?>"><?php echo e($tabYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>
                                                            <td><button id="removeTabRow" class="btn btn-danger" type="button">remove</button></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                            </table>

                                            <div class="row d-flex align-items-center">
                                                <h5 class="ml-2 pr-4 font-weight-bold">Size</h5>
                                                <button type="button" class="btn btn-success font-weight-bold m-2 text-white" id="addSizeRow">Add Row</button>
                                            </div>
                                            <table class="table table-bordered text-nowrap">
                                                <thead>
                                                    <tr>
                                                        <th>Needle No</th>
                                                        <th>Pantone</th>
                                                        <th>Color</th>
                                                        <th>Shade</th>
                                                        <th>Denier</th>
                                                        <th>A</th>
                                                        <th>B</th>
                                                        <th>C</th>
                                                        <th>D</th>
                                                        <th>E</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="add_size_new_row">
                                                    <?php if($editdesignCard): ?>
                                                        <?php $__empty_1 = true; $__currentLoopData = $editdesignCard->size_needle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeIndex => $sizeNeedle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <tr class="inputSizeFormRow">
                                                                <td><input type="text" readonly class="size_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[<?php echo e($sizeIndex); ?>][needle_no]" value="<?php echo e($sizeNeedle['needle_no']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[<?php echo e($sizeIndex); ?>][pantone]" value="<?php echo e($sizeNeedle['pantone']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="color" class="size_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[<?php echo e($sizeIndex); ?>][color]" value="<?php echo e($sizeNeedle['color']); ?>" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="size_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="size_needle[<?php echo e($sizeIndex); ?>][color_shade]" value="<?php echo e($sizeNeedle['color_shade']); ?>"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[<?php echo e($sizeIndex); ?>][denier]"  value="<?php echo e($sizeNeedle['denier']); ?>" placeholder="Enter the value"></td>
                                                                <td>
                                                                    <select name="size_needle[<?php echo e($sizeIndex); ?>][a]" class="size_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select A</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>" <?php echo e($sizeYarn['id'] == $sizeNeedle['a'] ? 'selected' : ''); ?> data-size_color="<?php echo e($sizeYarn['yarn_color']); ?>" data-size_shade="<?php echo e($sizeYarn['color_shade']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="size_needle[<?php echo e($sizeIndex); ?>][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select B</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>" <?php echo e($sizeYarn['id'] == $sizeNeedle['b'] ? 'selected' : ''); ?> ><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="size_needle[<?php echo e($sizeIndex); ?>][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select C</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>" <?php echo e($sizeYarn['id'] == $sizeNeedle['c'] ? 'selected' : ''); ?> ><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="size_needle[<?php echo e($sizeIndex); ?>][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select D</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>" <?php echo e($sizeYarn['id'] == $sizeNeedle['d'] ? 'selected' : ''); ?> ><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td>
                                                                    <select name="size_needle[<?php echo e($sizeIndex); ?>][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select E</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>" <?php echo e($sizeYarn['id'] == $sizeNeedle['e'] ? 'selected' : ''); ?> ><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td><button id="removeSizeRow" class="btn btn-danger" type="button">remove</button></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <tr class="inputSizeFormRow">
                                                                <td><input type="text" readonly class="size_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][needle_no]" value="1" placeholder="Enter the value"></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][pantone]" value="" placeholder="Enter the value"></td>
                                                                <td><input type="color" class="size_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][color]" value="" placeholder="Enter the value"></td>
                                                                <td><input type="text" class="size_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][color_shade]" value=""></td>
                                                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][denier]"  value="" placeholder="Enter the value"></td>
                                                                <td>
                                                                    <select name="size_needle[0][a]" class="size_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select A</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>" data-size_color="<?php echo e($sizeYarn['yarn_color']); ?>" data-size_shade="<?php echo e($sizeYarn['color_shade']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="size_needle[0][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select B</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="size_needle[0][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select C</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="size_needle[0][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select D</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>

                                                                <td>
                                                                    <select name="size_needle[0][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                        <option value="">Select E</option>
                                                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </td>
                                                                <td><button id="removeSizeRow" class="btn btn-danger" type="button">remove</button></td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        <tr class="inputSizeFormRow">
                                                            <td><input type="text" readonly class="size_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][needle_no]" value="1" placeholder="Enter the value"></td>
                                                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][pantone]" value="" placeholder="Enter the value"></td>
                                                            <td><input type="color" class="size_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="size_needle[0][color]" value="" placeholder="Enter the value"></td>
                                                            <td><input type="text" class="size_color_shade" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="size_needle[0][color_shade]" value=""></td>
                                                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[0][denier]"  value="" placeholder="Enter the value"></td>
                                                            <td>
                                                                <select name="size_needle[0][a]" class="size_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select A</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($sizeYarn['id']); ?>" data-size_color="<?php echo e($sizeYarn['yarn_color']); ?>" data-size_shade="<?php echo e($sizeYarn['color_shade']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="size_needle[0][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select B</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="size_needle[0][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select C</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="size_needle[0][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select D</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>

                                                            <td>
                                                                <select name="size_needle[0][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                                                    <option value="">Select E</option>
                                                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeYarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($sizeYarn['id']); ?>"><?php echo e($sizeYarn['shade_No']); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </td>
                                                            <td><button id="removeSizeRow" class="btn btn-danger" type="button">remove</button></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                </tbody>
                                                
                                            </table>
                                        </div>
                                    </div>
                                    <div class="col-3">
                                        <div class="form-group">
                                            <div class="object-fit-container">   
                                                <?php if($editdesignCard): ?>
                                                    <?php if($editdesignCard->front_image): ?>
                                                        <img class="object-fit-cover" src="<?php echo e(asset('./designCards/'.$editdesignCard->front_image)); ?>" id="result" />
                                                    <?php else: ?>
                                                        <img class="object-fit-cover" id="result" />
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <img class="object-fit-cover" id="result" />                                                  
                                                <?php endif; ?>
                                            </div>
                                            <div class="mt-4">
                                                <label for="file">Front Image</label>
                                                <input type="hidden" name="front_image" id="front_crop_image">
                                                <input type="file" id="file" name="front_crop_image" class="<?php $__errorArgs = ['front_crop_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*">
                                                <?php $__errorArgs = ['front_crop_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div> 
                                        <hr>
                                        <div class="form-group">
                                            <div class="object-fit-container">  
                                                <?php if($editdesignCard): ?>
                                                    <?php if($editdesignCard->back_image): ?>
                                                        <img class="object-fit-cover" src="<?php echo e(asset('./designCards/'.$editdesignCard->back_image)); ?>" id="result1" />
                                                    <?php else: ?>
                                                        <img class="object-fit-cover" id="result1" />
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <img class="object-fit-cover" id="result1" />
                                                <?php endif; ?> 
                                            </div>
                                            <div class="mt-4">
                                                <label for="file">Back Image</label>
                                                <input type="hidden" name="back_image" id="back_crop_image">
                                                <input type="file" id="file1" class="<?php $__errorArgs = ['back_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*" name="back_crop_image">
                                                <?php $__errorArgs = ['back_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                                            </div>
                                        </div> 
                                        <hr>
                                        <div class="form-group">
                                            <div class="object-fit-container">   
                                                <?php if($editdesignCard): ?>
                                                    <?php if($editdesignCard->all_view_image): ?>
                                                        <img class="object-fit-cover" src="<?php echo e(asset('./designCards/'.$editdesignCard->all_view_image)); ?>" id="result2" />
                                                    <?php else: ?>
                                                        <img class="object-fit-cover" id="result2" />
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <img class="object-fit-cover" id="result2" />
                                                <?php endif; ?> 
                                            </div>
                                            <div class="mt-4">
                                                <label for="file">All View Image</label>
                                                <input type="hidden" name="all_view_image" id="all_view_crop_image">
                                                <input type="file" id="file2" class="<?php $__errorArgs = ['all_view_crop_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*" name="all_view_crop_image"> 
                                                <?php $__errorArgs = ['all_view_crop_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> 
                                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>                                              
                                            </div>
                                        </div> 
                                        <hr>
                                        <div class="form-group">
                                            <div class="mt-4">
                                                <label for="document_name">Design File</label>
                                                <input type="file" id="document_name" multiple name="design_files[]">
                                                <?php $errMsg = $errors->get('design_files.*'); ?>
                                                <?php if(isset($errMsg["design_files.0"][0])): ?>
                                                    <div class="form-text" role="alert">
                                                        <small class="text-danger font-weight-bold">
                                                            <?php echo e($errMsg["design_files.0"][0]); ?>

                                                        </small>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                            </div>
                            <!-- /.card-body -->
                            <div class="card-footer">
                                <button type="submit" class="btn btn-primary float-right"><?php echo e($editdesignCard ? 'Update' : 'Save'); ?></button>
                            </div>
                        </form>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <link href="https://www.jqueryscript.net/css/jquerysctipttop.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/pixelarity.css')); ?>">
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha384-vk5WoKIaW/vJyUAd9n/wmopsmNhiy+L2Z+SBxGYnUkunIxVxAv/UtMOhba/xskxh" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $(function () {
            $("#main_table_row").on('input', '.main_txt_cal', function () {
                var calculated_total_sum = 0;
                
                $("#main_table_row .main_txt_cal").each(function () {
                    var get_textbox_value = $(this).val();
                    if ($.isNumeric(get_textbox_value)) {
                        calculated_total_sum += parseFloat(get_textbox_value);
                    }                  
                });
                $("#main_total_value").val(calculated_total_sum);
                console.log(calculated_total_sum);
            });

            $("#tab_table_row").on('input', '.tab_txt_cal', function () {
                var calculated_total_sum = 0;
                
                $("#tab_table_row .tab_txt_cal").each(function () {
                    var get_textbox_value = $(this).val();
                    if ($.isNumeric(get_textbox_value)) {
                        calculated_total_sum += parseFloat(get_textbox_value);
                    }                  
                });
                $("#tab_total_value").val(calculated_total_sum);
                console.log(calculated_total_sum);
            });

            $("#size_table_row").on('input', '.size_txt_cal', function () {
                var calculated_total_sum = 0;
                
                $("#size_table_row .size_txt_cal").each(function () {
                    var get_textbox_value = $(this).val();
                    if ($.isNumeric(get_textbox_value)) {
                        calculated_total_sum += parseFloat(get_textbox_value);
                    }                  
                });
                $("#size_total_value").val(calculated_total_sum);
                console.log(calculated_total_sum);
            });
        });
        
        // main row starts
        var index = 0;
        $("#addMainRow").click(function () {
            index++;
            let mainSequenceNo = $('.inputMainFormRow').length + 1;
            var html = `<tr class="inputMainFormRow">
                            <td><input type="text" readonly class="main_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="main_needle[${index}][needle_no]" value="${mainSequenceNo}" placeholder="Enter the value"></td>
                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="main_needle[${index}][pantone]" value="" placeholder="Enter the value"></td>
                            <td><input type="color" class="main_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="main_needle[${index}][color]" value="" placeholder="Enter the value"></td>
                            <td><input type="text" class="main_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[${index}][color_shade]" value=""></td>
                            <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="main_needle[${index}][denier]"  value="" placeholder="Enter the value"></td>
                         
                            <td>
                                <select name="main_needle[${index}][a]" class="main_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                    <option value="">Select Yarn</option>
                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($yarn['id']); ?>" data-main_color="<?php echo e($yarn['yarn_color']); ?>" data-main_shade="<?php echo e($yarn['color_shade']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td>
                                <select name="main_needle[${index}][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                    <option value="">Select Yarn</option>
                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td>
                                <select name="main_needle[${index}][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                    <option value="">Select Yarn</option>
                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td>
                                <select name="main_needle[${index}][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                    <option value="">Select Yarn</option>
                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td>
                                <select name="main_needle[${index}][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                    <option value="">Select Yarn</option>
                                    <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>

                            <td><button id="removeMainRow" class="btn btn-danger" type="button">remove</button></td>
                        </tr>`
            $('#add_main_new_row').append(html);
        });

        $(document).on('click', '#removeMainRow', function () {
            let tabl = $('.inputMainFormRow').length;
            if(tabl === 1)
            {
                alert("Sorry you can't remove this row");
            }
            else
            {
                $(this).closest('.inputMainFormRow').remove();
                $('.inputMainFormRow').each(function(i){
                    $(this).find('.main_sequence').val(i+1);
                });
            }
        });
        
        $(document).on("change",".main_yarn",function(){
            const mainColor = $(this).find(':selected').data('main_color');
            const mainShade = $(this).find(':selected').data('main_shade');
            $(this).closest('tr').find('.main_color').val(mainColor);
            $(this).closest('tr').find('.main_color_shade').val(mainShade);
        });
        // main row ends

        // tab row starts
        var tabIndex = 0;
        $("#addTabRow").click(function () {
            tabIndex++;
            let tabSequenceNo = $('.inputTabFormRow').length + 1;
            var tabHtml = `<tr class="inputTabFormRow">
                                <td><input type="text" readonly class="tab_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="tab_needle[${tabIndex}][needle_no]" value="${tabSequenceNo}" placeholder="Enter the value"></td>
                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="tab_needle[${tabIndex}][pantone]" value="" placeholder="Enter the value"></td>
                                <td><input type="color" class="tab_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="tab_needle[${tabIndex}][color]" value="" placeholder="Enter the value"></td>
                                <td><input type="text" class="tab_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[${tabIndex}][color_shade]" value=""></td>
                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="tab_needle[${tabIndex}][denier]"  value="" placeholder="Enter the value"></td>

                                <td>
                                    <select name="tab_needle[${tabIndex}][a]" class="tab_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select A</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>" data-tab_color="<?php echo e($yarn['yarn_color']); ?>" data-tab_shade="<?php echo e($yarn['color_shade']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="tab_needle[${tabIndex}][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select B</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="tab_needle[${tabIndex}][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select C</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="tab_needle[${tabIndex}][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select D</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="tab_needle[${tabIndex}][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select E</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td><button id="removeTabRow" class="btn btn-danger" type="button">remove</button></td>
                            </tr>`;
        
            $('#add_tab_new_row').append(tabHtml);
        });

        $(document).on('click', '#removeTabRow', function () {
            let tabl = $('.inputTabFormRow').length;
            if(tabl === 1)
            {
                alert("Sorry you can't remove this row");
            }
            else
            {
                $(this).closest('.inputTabFormRow').remove();
                $('.inputTabFormRow').each(function(i){
                    $(this).find('.tab_sequence').val(i+1);
                });
            }
        });

        $(document).on("change",".tab_yarn",function(){
            const tabColor = $(this).find(':selected').data('tab_color');
            const tabShade = $(this).find(':selected').data('tab_shade');
            $(this).closest('tr').find('.tab_color').val(tabColor);
            $(this).closest('tr').find('.tab_color_shade').val(tabShade);
        });
        // tab row ends

        // size row starts
        var sizeIndex = 0;
        $("#addSizeRow").click(function () {
            sizeIndex++;
            let sizeSequenceNo = $('.inputSizeFormRow').length + 1;
            var sizeHtml = `<tr class="inputTabFormRow">
                                <td><input type="text" readonly class="size_sequence" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="size_needle[${sizeIndex}][needle_no]" value="${sizeSequenceNo}" placeholder="Enter the value"></td>
                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" name="size_needle[${sizeIndex}][pantone]" value="" placeholder="Enter the value"></td>
                                <td><input type="color" class="size_color" style="border-radius:.25rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;" class="form-controls" name="size_needle[${sizeIndex}][color]" value="" placeholder="Enter the value"></td>
                                <td><input type="text" class="size_color_shade" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[${sizeIndex}][color_shade]" value=""></td>
                                <td><input type="text" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;"  name="size_needle[${sizeIndex}][denier]"  value="" placeholder="Enter the value"></td>

                                <td>
                                    <select name="size_needle[${sizeIndex}][a]" class="size_yarn" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select A</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($yarn['id']); ?>" data-size_color="<?php echo e($yarn['yarn_color']); ?>" data-size_shade="<?php echo e($yarn['color_shade']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="size_needle[${sizeIndex}][b]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select B</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="size_needle[${sizeIndex}][c]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select C</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="size_needle[${sizeIndex}][d]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select D</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td>
                                    <select name="size_needle[${sizeIndex}][e]" style="border-radius:.25rem; padding:.375rem .75rem; color: #495057; background-color: #fff;  border: 1px solid #ced4da;">
                                        <option value="">Select E</option>
                                        <?php $__currentLoopData = $data['yarnMaster']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($yarn['id']); ?>"><?php echo e($yarn['shade_No']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>

                                <td><button id="removeSizeRow" class="btn btn-danger" type="button">remove</button></td>
                            </tr>`;
            $('#add_size_new_row').append(sizeHtml);
        });

        $(document).on('click', '#removeSizeRow', function () {
            let tabl = $('.inputSizeFormRow').length;
            if(tabl === 1)
            {
                alert("Sorry you can't remove this row");
            }
            else
            {
                $(this).closest('.inputSizeFormRow').remove();
                $('.inputSizeFormRow').each(function(i){
                    $(this).find('.size_sequence').val(i+1);
                });
            }
        });

        $(document).on("change",".size_yarn",function(){
            const sizeColor = $(this).find(':selected').data('size_color');
            const sizeShade = $(this).find(':selected').data('size_shade');
            $(this).closest('tr').find('.size_color').val(sizeColor);
            $(this).closest('tr').find('.size_color_shade').val(sizeShade);
        });
        // size row ends     

        const airjet_16Speed   = "<?php echo e($data['loomrMaster'][0]['speed']); ?>";
        const airjet_12Speed   = "<?php echo e($data['loomrMaster'][1]['speed']); ?>";
        const mullerSpeed      = "<?php echo e($data['loomrMaster'][2]['speed']); ?>";

        $("#main_total_picks, #main_repeat_first_input").on("keyup",function(){
            const mainTotalPicks  = parseFloat($('#main_total_picks').val());        
            const mainLabFst      = $("#main_labelhrs_first");
            const mainLabsec      = $("#main_labelhrs_second");
            const mainLabThir     = $("#main_labelhrs_third");
            const mainRepFst      = $("#main_repeat_first_input");
            const mainRepSec      = $("#main_repeat_second_input");
            const mainRepThir     = $("#main_repeat_last_input");

            if(($("#main_total_picks").val() && !isNaN($("#main_total_picks").val())) && ($("#main_repeat_first_input").val() && !isNaN($("#main_repeat_first_input").val()))){
              const mainLabFirst  = (parseFloat(mullerSpeed)/mainTotalPicks)*parseFloat(mainRepFst.val())*60*0.85;
              const mainLabSecond = (parseFloat(airjet_12Speed)/mainTotalPicks)*(mainRepFst.val()*1.2)*60*0.85;
              const mainLabThird  = (parseFloat(airjet_16Speed)/mainTotalPicks)*(mainRepFst.val()*1.6)*60*0.85;
              mainLabFst.val(Math.floor(mainLabFirst));
              mainLabsec.val(Math.floor(mainLabSecond));
              mainLabThir.val(Math.floor(mainLabThird));
            
            }else{
                mainLabFst.val('');
                mainLabsec.val('');
                mainLabThir.val('');
            }
        });

        $("#main_repeat_first_input").on("keyup",function(){
            const mainRepFirst   = $(this).val()
            const mainRepSecond  = $("#main_repeat_second_input");
            const mainRepThird   = $("#main_repeat_last_input");
               
            if(mainRepFirst && !isNaN(mainRepFirst)){
                const mainFirstCal = parseFloat(mainRepFirst) * 1.2;
                const mainLastCal  = parseFloat(mainRepFirst) * 1.6;

                mainRepSecond.val(Math.floor(mainFirstCal));
                mainRepThird.val(Math.floor(mainLastCal));
            }
            else{
                mainRepSecond.val('');
                mainRepThird.val('');
            }
        });

        $("#tab_total_picks, #tab_repeat_first_input").on("keyup",function(){
            const tabTotalPicks  = parseFloat($("#tab_total_picks").val());        
            const tabLabFst      = $("#tab_labelhrs_first");
            const tabLabsec      = $("#tab_labelhrs_second");
            const tabLabThir     = $("#tab_labelhrs_third");
            const tabRepFst      = $("#tab_repeat_first_input");
            const tabRepSec      = $("#tab_repeat_second_input");
            const tabRepThir     = $("#tab_repeat_last_input");

            if(($("#tab_total_picks").val() != "" && !isNaN($("#tab_total_picks").val())) && ($("#tab_repeat_first_input").val() !="" && !isNaN($("#tab_repeat_first_input").val()))){
              const tabLabFirst  = (parseFloat(mullerSpeed)/tabTotalPicks)*parseFloat(tabRepFst.val())*60*0.85;
              const tabLabSecond = (parseFloat(airjet_12Speed)/tabTotalPicks)*(tabRepFst.val() * 1.2)*60*0.85;
              const tabLabThird  = (parseFloat(airjet_16Speed)/tabTotalPicks)*(tabRepFst.val() * 1.6)*60*0.85;
              tabLabFst.val(Math.floor(tabLabFirst));
              tabLabsec.val(Math.floor(tabLabSecond));
              tabLabThir.val(Math.floor(tabLabThird));
            
            }else{
                tabLabFst.val('');
                tabLabsec.val('');
                tabLabThir.val('');
            }
        });

        $("#tab_repeat_first_input").on("keyup",function(){
            const tabRepFirst      = $(this).val();
            const tabRepSecond     = $("#tab_repeat_second_input");
            const tabRepThird      = $("#tab_repeat_last_input");
            
            if(tabRepFirst && !isNaN(tabRepFirst)){
                const tabFirstCal     = parseFloat(tabRepFirst) * 1.2;
                const tabLastCal      = parseFloat(tabRepFirst) * 1.6;

                tabRepSecond.val(Math.floor(tabFirstCal));
                tabRepThird.val(Math.floor(tabLastCal));
            }else{
                tabRepSecond.val("");
                tabRepThird.val("");
            }
        });

        $("#size_total_picks, #size_repeat_first_input").on("keyup",function(){
            const sizeTotalPicks  = parseFloat($("#size_total_picks").val());        
            const sizeLabFst      = $("#size_labelhrs_first");
            const sizeLabsec      = $("#size_labelhrs_second");
            const sizeLabThir     = $("#size_labelhrs_third");
            const sizeRepFst      = $("#size_repeat_first_input");
            const sizeRepSec      = $("#size_repeat_second_input");
            const sizeRepThir     = $("#size_repeat_last_input");

            if(($("#size_total_picks").val() && !isNaN($("#size_total_picks").val())) && ($("#size_repeat_first_input").val() && !isNaN($("#size_repeat_first_input").val()))){
              const sizeLabFirst  = (parseFloat(mullerSpeed)/sizeTotalPicks)*parseFloat(sizeRepFst.val())*60*0.85;
              const sizeLabSecond = (parseFloat(airjet_12Speed)/sizeTotalPicks)*(sizeRepFst.val()*1.2)*60*0.85;
              const sizeLabThird  = (parseFloat(airjet_16Speed)/sizeTotalPicks)*(sizeRepFst.val()*1.6)*60*0.85;
              sizeLabFst.val(Math.floor(sizeLabFirst));
              sizeLabsec.val(Math.floor(sizeLabSecond));
              sizeLabThir.val(Math.floor(sizeLabThird));
            
            }else{
                sizeLabFst.val('');
                sizeLabsec.val('');
                sizeLabThir.val('');
            }
        });

        $("#size_repeat_first_input").on("keyup",function(){
            const sizeRepFirst    = $(this).val();
            const sizeRepSecond   = $("#size_repeat_second_input");
            const sizeRepThird    = $("#size_repeat_last_input");

            if(sizeRepFirst && !isNaN(sizeRepFirst)){
                const sizeFirstCal = parseFloat(sizeRepFirst) * 1.2;
                const sizeLastCal  = parseFloat(sizeRepFirst) * 1.6;
                sizeRepSecond.val(Math.floor(sizeFirstCal));
                sizeRepThird.val(Math.floor(sizeLastCal));
            }else{
                sizeRepSecond.val("");
                sizeRepThird.val("");
            }
        });

        $("#main_width_input, #main_length_input").on("keyup",function(){
            let main_width = parseFloat($("#main_width_input").val());
            let main_length = parseFloat($("#main_length_input").val());
            let main_sq_mm = main_width * main_length;
            let main_sq_inch = main_sq_mm * 0.03937;
            if (!isNaN(main_sq_mm)) {
                $("#main_sq_mm_input").val(main_sq_mm);
                $("#main_sq_inch_input").val(main_sq_inch.toFixed(3));
            }
            else {
                $("#main_sq_mm_input").val("");
                $("#main_sq_inch_input").val("");
            }
        });

        $("#tab_width_input, #tab_length_input").on("keyup",function(){
            console.log("typing");
            let tab_width = parseFloat($("#tab_width_input").val());
            let tab_length = parseFloat($("#tab_length_input").val());
            let tab_sq_mm = tab_width * tab_length;
            let tab_sq_inch = tab_sq_mm * 0.03937;
            if (!isNaN(tab_sq_mm)) {
                $("#tab_sq_mm_input").val(tab_sq_mm);
                $("#tab_sq_inch_input").val(tab_sq_inch.toFixed(3));
            }
            else {
                $("#tab_sq_mm_input").val("");
                $("#tab_sq_inch_input").val("");
            }
        });

        $("#size_width_input, #size_length_input").on("keyup",function(){
            let size_width = parseFloat($("#size_width_input").val());
            let size_length = parseFloat($("#size_length_input").val());
            let size_sq_mm = size_width * size_length;
            let size_sq_inch = size_sq_mm * 0.03937;
            if (!isNaN(size_sq_mm)) {
                $("#size_sq_mm_input").val(size_sq_mm);
                $("#size_sq_inch_input").val(size_sq_inch.toFixed(3));
            }
            else {
                $("#size_sq_mm_input").val("");
                $("#size_sq_inch_input").val("");
            }
        });

        $("#tab_label").on("change",function(){
            var tablabel_val = $(this).val() == 'no' ? 'yes' : 'no';
            $("#tab_label").val(tablabel_val);
            $(".tab_label_input").toggleClass("d-none");
        });

        $("#size_label").on("change",function(){
            var tablabel_val = $(this).val() == 'no' ? 'yes' : 'no';
            $("#size_label").val(tablabel_val);
            $(".size_label_input").toggleClass("d-none");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ieemail/hilife.inevitabletech.email/resources/views/woven/create.blade.php ENDPATH**/ ?>