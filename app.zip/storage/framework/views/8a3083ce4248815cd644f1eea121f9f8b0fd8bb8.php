

<?php $__env->startSection('title', 'looms'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('looms')); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('looms.create')); ?>" class="btn bg-gradient-primary float-right">Add looms</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has($message)): ?>
                        <div class="alert alert-<?php echo e($message); ?>">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo e(session($message)); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">looms</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered table-sm">
                            <thead>
                            <tr>
                                <th style="width: 50px">#</th>
                                <th>Loom Name</th>
                                <th>Weaving</th>
                                <th>Sections</th>
                                <th>Speed</th>
                                <th>Year</th>
                                <th>Notes</th>
                                <th style="width: 200px">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $looms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $loom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($loom->loom_name); ?></td>
                                    <td><?php echo e($loom->weaving_width_Meter); ?></td>
                                    <td><?php echo e($loom->sections); ?></td>
                                    <td><?php echo e($loom->speed); ?></td>
                                    <td><?php echo e($loom->year); ?></td>
                                    <td><?php echo e($loom->notes); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('looms.show',$loom->id)); ?>" class="btn btn-sm btn-warning">View</a>
                                        <?php if(!$loom->deleted_at): ?>
                                        <a href="<?php echo e(route('looms.edit',$loom->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                        <form method="POST" action="<?php echo e(route('looms.destroy', $loom->id)); ?>"
                                              accept-charset="UTF-8"
                                              style="display: inline-block;"
                                              onsubmit="return confirm('Are you sure do you want to delete?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="float-right">
                            <?php echo $looms->links(); ?>

                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/looms/index.blade.php ENDPATH**/ ?>