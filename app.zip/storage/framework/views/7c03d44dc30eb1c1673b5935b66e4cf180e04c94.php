<?php $__env->startSection('title', 'Seller'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('Seller - ') . $seller->first_name); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('sellers.index')); ?>" class="btn bg-gradient-primary float-right">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Sellers</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                        <table class="table table-bordered table-sm">
                                <tbody>
                                
                                    <tr>
                                        <td><strong><?php echo e(__('First Name')); ?></strong></td>
                                        <td><?php echo e($seller->first_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Last Name')); ?></strong></td>
                                        <td><?php echo e($seller->last_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Email')); ?></strong></td>
                                        <td><?php echo e($seller->email); ?></td>
                                    </tr>
                                   
                                    <tr>
                                        <td><strong><?php echo e(__('Phone')); ?></strong></td>
                                        <td><?php echo e($seller->mobile_number); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Bank Name')); ?></strong></td>
                                        <td><?php echo e($seller->bank_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Account Number')); ?></strong></td>
                                        <td><?php echo e($seller->account_no); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('IFSC Code')); ?></strong></td>
                                        <td><?php echo e($seller->IFSCCode); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Opening Balance')); ?></strong></td>
                                        <td><?php echo e($seller->opening_balance); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Credit Period')); ?></strong></td>
                                        <td><?php echo e($seller->credit_period); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Grade')); ?></strong></td>
                                        <td><?php echo e($seller->grade); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Billing Address')); ?></strong></td>
                                        <td><?php echo e($seller->billing_address); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Shipping Address')); ?></strong></td>
                                        <td><?php echo e($seller->shipping_address); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/sellers/show.blade.php ENDPATH**/ ?>