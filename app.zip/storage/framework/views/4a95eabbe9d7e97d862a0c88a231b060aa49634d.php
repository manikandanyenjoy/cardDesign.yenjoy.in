

<?php $__env->startSection('title', 'Vendor Detail'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-1">
        <div class="offset-md-1 col-md-10">
            <h1 class="float-left ml-2 font-weight-bold">
                <?php echo e(__('Seller - ') . ucwords($seller->full_name)); ?>

            </h1>
            <div class="float-right">
                <a href="<?php echo e(route('sellers.edit',$seller->id)); ?>" class="btn bg-gradient-success btn-md mr-2"><?php echo e(__('Edit')); ?></a>
                <a href="<?php echo e(route('sellers.index')); ?>" class="btn bg-gradient-danger btn-md mr-2"><?php echo e(__('Back')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-1 col-md-10">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Seller Detail</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                
                                    <tr>
                                        <td><strong><?php echo e(__('Full Name')); ?></strong></td>
                                        <td><?php echo e(ucfirst($seller->full_name)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Category')); ?></strong></td>
                                        <td><?php echo e($seller->categoryMasterDetail ? ucfirst($seller->categoryMasterDetail->category_name) : '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Email')); ?></strong></td>
                                        <td><?php echo e($seller->email); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Phone')); ?></strong></td>
                                        <td><?php echo e($seller->mobile_number); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Bank Name')); ?></strong></td>
                                        <td><?php echo e(ucwords($seller->bank_name)); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Account Number')); ?></strong></td>
                                        <td><?php echo e($seller->account_no); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('IFSC Code')); ?></strong></td>
                                        <td><?php echo e($seller->IFSCCode); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Opening Balance')); ?></strong></td>
                                        <td><?php echo e($seller->opening_balance); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Credit Period')); ?></strong></td>
                                        <td><?php echo e($seller->credit_period); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Grade')); ?></strong></td>
                                        <td><?php echo e($seller->grade); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('GST No')); ?></strong></td>
                                        <td><?php echo e($seller->GST); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Billing Address')); ?></strong></td>
                                        <td><?php echo e($seller->billing_address); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Shipping Address')); ?></strong></td>
                                        <td><?php echo e($seller->shipping_address); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/sellers/show.blade.php ENDPATH**/ ?>