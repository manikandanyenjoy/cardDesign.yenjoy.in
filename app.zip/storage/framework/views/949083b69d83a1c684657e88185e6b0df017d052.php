<?php $__env->startSection('title', 'wovenquality'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('wovenquality ')); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('wovenqualitys.index')); ?>" class="btn bg-gradient-primary float-right">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">wovenquality</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('Quality')); ?></strong></td>
                                        <td><?php echo e($wovenquality->quality); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Material')); ?></strong></td>
                                        <td><?php echo e($wovenquality->material); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Notes')); ?></strong></td>
                                        <td><?php echo e($wovenquality->notes); ?></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/wovenqualitys/show.blade.php ENDPATH**/ ?>