

<?php if($editCategory): ?>
    <?php $__env->startSection('title', 'Edit Category'); ?>
<?php else: ?>
    <?php $__env->startSection('title', 'Create Category'); ?>
<?php endif; ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row justify-content-center">
        <div class="col-sm-7">
            <h1><?php echo e(__('Category')); ?></h1>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-md-7">

                <?php echo $__env->make('shared.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- general form elements -->
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e($editCategory ? __('Edit Category') : __('Create Category')); ?></h3>
                        </div>
                        <form method="POST" action="<?php echo e($editCategory ? route('category.update', $editCategory->id) : route('category.store')); ?>" novalidate>
                            <?php if($editCategory): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
                            <?php echo csrf_field(); ?>
                            <div class="card-body row">
                                <div class="form-group col-12">
                                    <label for="category_name">Category Name</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="category_name" name="category_name" value="<?php echo e($editCategory ? old('category_name',$editCategory->category_name) : old('category_name')); ?>" placeholder="Category Name">
                                    <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="error invalid-feedback"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <!-- /.card-body -->

                            <div class="card-footer text-center">
                                <button type="submit" class="btn btn-primary btn-md col-3"><?php echo e($editCategory ? __('Update') : __('Save')); ?></button>
                                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-danger btn-md col-3"><?php echo e(__('Cancel')); ?></a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ieemail/hilife.inevitabletech.email/resources/views/category/create.blade.php ENDPATH**/ ?>