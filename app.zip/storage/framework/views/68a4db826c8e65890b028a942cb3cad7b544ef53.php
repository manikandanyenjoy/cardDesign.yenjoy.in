

<?php $__env->startSection('title', 'Raw Material'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-1">
        <div class="col-12">
            <h1 class="float-left ml-2 font-weight-bold">
              <?php echo e(__('Raw Material')); ?>

            </h1>
            <div class="float-right">
                <a href="<?php echo e(route('yarns.create')); ?>" class="btn bg-gradient-primary btn-md mr-2"><?php echo e(__('Add Raw Material')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Session::has($message)): ?>
                        <div class="alert alert-<?php echo e($message); ?>">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <?php echo e(session($message)); ?>

                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card card-primary">
                    <div class="card-header">
                        <h3 class="card-title">List of Raw Materials</h3>
                      <form class="float-right">
                          <input class="" type="text" name="search" >
                          <button class="btn btn-sm btn-info" type="submit">
                            search
                          </button>
                      </form>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                        <table class="table table-bordered table-sm">
                            <thead>
                            <tr>
                                <th style="width: 50px">#</th>
                                <th>supplier Name</th>
                                <th>Yarn Denier</th>
                                <th>Shade No</th>
                                <th>Yarn Color</th>
                                <th>Color Shade</th>
                                <th>Notes</th>
                                <th style="width: 200px">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $i = ($yarns->currentpage()-1)* $yarns->perpage() + 1; ?>
                                <?php $__empty_1 = true; $__currentLoopData = $yarns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yarn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($yarn->supplier); ?></td>
                                        <td><?php echo e($yarn->yarn_denier); ?></td>
                                        <td><?php echo e($yarn->shade_No); ?></td>
                                        <td><?php echo e($yarn->yarn_color); ?></td>
                                        <td style="background-color: <?php echo e($yarn->yarn_color); ?>;"></td>
                                        <td><?php echo e($yarn->notes); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('yarns.show',$yarn->id)); ?>" class="btn btn-sm btn-warning">View</a>
                                            <?php if(!$yarn->deleted_at): ?>
                                            <a href="<?php echo e(route('yarns.edit',$yarn->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                                            <form method="POST" action="<?php echo e(route('yarns.destroy', $yarn->id)); ?>"
                                                accept-charset="UTF-8"
                                                style="display: inline-block;"
                                                onsubmit="return confirm('Are you sure do you want to delete?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <input class="btn btn-sm btn-danger" type="submit" value="Delete">
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <th colspan="8" class="text-center">No Data Found...</th>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- /.card-body -->
                    <div class="card-footer clearfix">
                        <div class="float-right">
                            <?php echo $yarns->links(); ?>

                        </div>
                    </div>
                </div>
                <!-- /.card -->
            </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ieemail/hilife.inevitabletech.email/resources/views/yarns/index.blade.php ENDPATH**/ ?>