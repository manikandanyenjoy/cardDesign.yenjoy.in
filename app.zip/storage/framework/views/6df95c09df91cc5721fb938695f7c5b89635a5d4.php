

<?php $__env->startSection('title', 'Finishing Operator'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-1">
        <div class="offset-md-1 col-md-10">
            <h1 class="font-weight-bold float-left">
                <?php echo e(__('Finishing Operator - ') . ucwords($finishingoperator->name)); ?>

            </h1>
            <div class="float-right">
                <a href="<?php echo e(route('staffs.edit',$finishingoperator->id)); ?>" class="btn bg-gradient-warning mr-2"><?php echo e(__('Edit')); ?></a>
                <a href="<?php echo e(route('finishingoperators.index')); ?>" class="btn bg-gradient-danger mr-2"><?php echo e(__('Back')); ?></a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-1 col-md-10">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">Finishing Operator Details</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('Full Name')); ?></strong></td>
                                        <td><?php echo e(ucwords($finishingoperator->name)); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Email')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->email); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Phone')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->phone); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Qualification')); ?></strong></td>
                                        <td><?php echo e(ucwords($finishingoperator->qualification)); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Role')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->roleDetial ? ucwords($finishingoperator->roleDetial->name) : '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Blood Group')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->blood_group ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Document ID')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->documentID ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Document File')); ?></strong></td>
                                        <td>
                                            <?php if($finishingoperator->document_name): ?>
                                                <a href="<?php echo e($finishingoperator->document_name); ?>" download><i class="fas fa-download mr-2"></i>Download</a>
                                            <?php else: ?>
                                                No document files 
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Joined On')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->joined_on); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Left On')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->left_on ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Address')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->address ?? '-'); ?></td>
                                    </tr>

                                    <tr>
                                        <td><strong><?php echo e(__('Status')); ?></strong></td>
                                        <td><?php echo e($finishingoperator->status == 1 ? 'Active' : 'Inactive'); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ieemail/hilife.inevitabletech.email/resources/views/finishingoperator/show.blade.php ENDPATH**/ ?>