

<?php $__env->startSection('title', 'View Design Card'); ?>
<style> 
    .table_wrp input {
        width: 100%;
        border: 0;
        outline: none;
    }
    input.input_hlf {
        width: 40px;
        padding: 0;
    }
       .object-fit-container {
           overflow:hidden;
        border: 2px solid;
        padding: 10px;
    
    height: 230px; /*any size*/
    }

    .object-fit-cover {
    width: auto;
    height: 100%;
    display: block;
    margin-left: auto;
    margin-right: auto;
    object-fit: cover; /*magic*/
    }
    tr.main_label_input {
    height: 45px!important;
}
</style>
<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-12 pr-4 d-flex justify-content-end">
            <button type="button" class="btn col-1 bg-gradient-success mr-3" id="print">Print</button>
            <a href="<?php echo e(route('woven.edit',$viewDesignCard->id)); ?>" class="btn col-1 bg-gradient-primary mr-3">Edit</a>
            <a href="<?php echo e(route('woven.index')); ?>" class="btn col-1 bg-gradient-danger">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary" id="print_area">
                        <div class="card-header">
                            <h3 class="card-title"><?php echo e(__('View Design Card - ')); ?> <span class="font-weight-bold"><?php echo e(ucfirst($viewDesignCard->label)); ?></span></h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div class="row">
                                <div class="col-9">
                                    <div class="table-responsive">
                                        <table class="table table-bordered text-nowrap">
                                            <tr>
                                                <th>Customer</th>
                                                <td><?php echo e($viewDesignCard->customerDetail ? ucwords($viewDesignCard->customerDetail->company_name ) : '-'); ?></td>
                                                <th>Label</th>
                                                <td><?php echo e(ucwords($viewDesignCard->label )); ?></td>
                                                <th>Date</th>
                                                <td><?php echo e($viewDesignCard->date); ?></td>
                                            </tr>

                                            <tr>
                                                <th>Designer</th>
                                                <td><?php echo e($viewDesignCard->designerDetail? ucwords($viewDesignCard->designerDetail->name ) : '-'); ?></td>
                                                <th>Sales Rep</th>
                                                <td><?php echo e(ucwords($viewDesignCard->salesRepDetail->name )); ?></td>
                                                <th>Weaver</th>
                                                <td width="150px">
                                                    <?php $__currentLoopData = $weavers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                     <?php echo e($w['name']); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                </td>
                                            </tr>

                                            <tr>
                                                <th>Warp</th>
                                                <td><?php echo e($viewDesignCard->warpDetail ? ucwords($viewDesignCard->warpDetail->name) : '-'); ?></td>
                                                <th>Folds</th>
                                                <td><?php echo e($viewDesignCard->foldMasterDetail ? ucwords($viewDesignCard->foldMasterDetail->type_of_fold ) : '-'); ?></td>
                                                <th>Notes</th>
                                                <td><?php echo e($viewDesignCard->description); ?></td>
                                            </tr>

                                            <tr>
                                                <th>Category</th>
                                                <td>
                                                    <?php echo e($viewDesignCard->categoryMasterDetail ? ucwords($viewDesignCard->categoryMasterDetail->category_name) : "-"); ?>

                                                </td>
                                                <td colspan="5"></td>
                                            </tr>
                                        </table>
                                                
                                        <div class="row">
                                            <div class="col">
                                                <table class="table table-bordered text-nowrap">
                                                    <tr>
                                                        <th></th>
                                                        <th>Main Label</th>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Design No</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['design_no']) ? $viewDesignCard->main_label['design_no'] : '-'); ?></td>
                                                    </tr>
                                                    
                                                    <tr class="main_label_input">
                                                        <th width="200px">Quality</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['quality']) ? $viewDesignCard->main_label['quality'] : '-'); ?></td>
                                                    </tr>
                                                    
                                                    <tr class="main_label_input">
                                                        <th width="200px">Picks/Cm</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['picks']) ? $viewDesignCard->main_label['picks'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Total Picks</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['total_picks']) ? $viewDesignCard->main_label['total_picks'] : '-'); ?></td>
                                                    </tr>
                                                    
                                                    <tr class="main_label_input">
                                                        <th width="200px">Total Repeat</th>
                                                        <td width="200px">
                                                            <?php if(isset($viewDesignCard->main_label['total_repeat'])): ?>
                                                                <?php $__currentLoopData = $viewDesignCard->main_label['total_repeat']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_repeat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                   <?php if(!empty($total_repeat) || $total_repeat != null || $total_repeat != ""): ?>
                                                                        <?php echo e($loop->first ? '' : ', '); ?>

                                                                        <?php echo e($total_repeat); ?>

                                                                    <?php else: ?>
                                                                        
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            -
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Total Labour Hours</th>
                                                        <td width="200px">
                                                            <?php if(isset($viewDesignCard->main_label['total_labour_hours'])): ?>
                                                                <?php $__currentLoopData = $viewDesignCard->main_label['total_labour_hours']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_labour_hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                   <?php if(!empty($total_labour_hours) || $total_labour_hours != null || $total_labour_hours != ""): ?>
                                                                        <?php echo e($loop->first ? '' : ', '); ?>

                                                                        <?php echo e($total_labour_hours); ?>

                                                                    <?php else: ?>
                                                                        
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            -
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Wastage</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['wastage']) ? $viewDesignCard->main_label['wastage'] : ''); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Width</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['width']) ? $viewDesignCard->main_label['width'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Length</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['length']) ? $viewDesignCard->main_label['length'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Sq mm</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['sq_mm']) ? $viewDesignCard->main_label['sq_mm'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <th width="200px">Sq inch</th>
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->main_label['sq_inch']) ? $viewDesignCard->main_label['sq_inch'] : '-'); ?></td>
                                                    </tr>
                                                </table>
                                            </div>

                                            <div class="col">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th>Tab Label</th>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['design_no']) ? $viewDesignCard->tab_label['design_no'] : '-'); ?></td>
                                                    </tr>
                                                    
                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['quality']) ? $viewDesignCard->tab_label['quality'] : '-'); ?></td>
                                                    </tr>
                                                    
                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['picks']) ? $viewDesignCard->tab_label['picks'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['total_picks']) ? $viewDesignCard->tab_label['total_picks'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['total_repeat'][0]) ? $viewDesignCard->tab_label['total_repeat'][0].',' : ''); ?> <?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['total_repeat'][1]) ? $viewDesignCard->tab_label['total_repeat'][1].',' : ''); ?> <?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['total_repeat'][1]) ? $viewDesignCard->tab_label['total_repeat'][1] : ''); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px">
                                                            <?php if(isset($viewDesignCard->tab_label['total_labour_hours'])): ?>
                                                                <?php $__currentLoopData = $viewDesignCard->tab_label['total_labour_hours']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_labour_hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                   <?php if(!empty($total_labour_hours) || $total_labour_hours != null || $total_labour_hours != ""): ?>
                                                                        <?php echo e($loop->first ? '' : ', '); ?>

                                                                        <?php echo e($total_labour_hours); ?>

                                                                    <?php else: ?>
                                                                        
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            -
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['wastage']) ? $viewDesignCard->tab_label['wastage'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['width']) ? $viewDesignCard->tab_label['width'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['length']) ? $viewDesignCard->tab_label['length'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['sq_mm']) ? $viewDesignCard->tab_label['sq_mm'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->tab_label['sq_inch']) ? $viewDesignCard->tab_label['sq_inch'] : '-'); ?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col">
                                                <table class="table table-bordered">
                                                    <tr>
                                                        <th>Size Label</th>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['design_no']) ? $viewDesignCard->size_label['design_no'] : '-'); ?></td>
                                                    </tr>
                                                    
                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['quality']) ? $viewDesignCard->size_label['quality'] : '-'); ?></td>
                                                    </tr>
                                                    
                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['picks']) ? $viewDesignCard->size_label['picks'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['total_picks']) ? $viewDesignCard->size_label['total_picks'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['total_repeat'][0]) ? $viewDesignCard->size_label['total_repeat'][0].',' : ''); ?> <?php echo e($viewDesignCard && isset($viewDesignCard->size_label['total_repeat'][1]) ? $viewDesignCard->size_label['total_repeat'][1].',' : ''); ?> <?php echo e($viewDesignCard && isset($viewDesignCard->size_label['total_repeat'][1]) ? $viewDesignCard->size_label['total_repeat'][1] : ''); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px">
                                                            <?php if(isset($viewDesignCard->size_label['total_labour_hours'])): ?>
                                                                <?php $__currentLoopData = $viewDesignCard->size_label['total_labour_hours']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $total_labour_hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                   <?php if(!empty($total_labour_hours) || $total_labour_hours != null || $total_labour_hours != ""): ?>
                                                                        <?php echo e($loop->first ? '' : ', '); ?>

                                                                        <?php echo e($total_labour_hours); ?>

                                                                    <?php else: ?>
                                                                        
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php else: ?>
                                                            -
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['wastage']) ? $viewDesignCard->size_label['wastage'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['width']) ? $viewDesignCard->size_label['width'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['length']) ? $viewDesignCard->size_label['length'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['sq_mm']) ? $viewDesignCard->size_label['sq_mm'] : '-'); ?></td>
                                                    </tr>

                                                    <tr class="main_label_input">
                                                        <td width="200px"><?php echo e($viewDesignCard && isset($viewDesignCard->size_label['sq_inch']) ? $viewDesignCard->size_label['sq_inch'] : '-'); ?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                    
                                        <table class="table table-bordered text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th>Add on</th>
                                                    <th>Basic</th>
                                                    <th>Cut fold</th>	
                                                    <th>Diecut</th>	
                                                    <th>Nonwoven</th>		
                                                    <th>Iron on back</th>
                                                    <th>Extras</th>
                                                    <th>Offered</th>
                                                    <th>TOTAL</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <th>Main</th>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['basic']) ? $viewDesignCard->add_on_main_cost['basic'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['cut_fold']) ? $viewDesignCard->add_on_main_cost['cut_fold'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['diecut']) ? $viewDesignCard->add_on_main_cost['diecut'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['nonwoven']) ? $viewDesignCard->add_on_main_cost['nonwoven'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['iron_on_back']) ? $viewDesignCard->add_on_main_cost['iron_on_back'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['extra']) ? $viewDesignCard->add_on_main_cost['extra'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['total']) ? $viewDesignCard->add_on_main_cost['total'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_main_cost['offered']) ? $viewDesignCard->add_on_main_cost['offered'] : '0'); ?></td>
                                                </tr>

                                                <tr>
                                                    <th>Tab</th>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['basic']) ? $viewDesignCard->add_on_tab_cost['basic'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['cut_fold']) ? $viewDesignCard->add_on_tab_cost['cut_fold'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['diecut']) ? $viewDesignCard->add_on_tab_cost['diecut'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['nonwoven']) ? $viewDesignCard->add_on_tab_cost['nonwoven'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['iron_on_back']) ? $viewDesignCard->add_on_tab_cost['iron_on_back'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['extra']) ? $viewDesignCard->add_on_tab_cost['extra'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['total']) ? $viewDesignCard->add_on_tab_cost['total'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_tab_cost['offered']) ? $viewDesignCard->add_on_tab_cost['offered'] : '0'); ?></td>
                                                </tr>

                                                <tr>
                                                    <th>Size</th>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['basic']) ? $viewDesignCard->add_on_size_cost['basic'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['cut_fold']) ? $viewDesignCard->add_on_size_cost['cut_fold'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['diecut']) ? $viewDesignCard->add_on_size_cost['diecut'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['nonwoven']) ? $viewDesignCard->add_on_size_cost['nonwoven'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['iron_on_back']) ? $viewDesignCard->add_on_size_cost['iron_on_back'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['extra']) ? $viewDesignCard->add_on_size_cost['extra'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['total']) ? $viewDesignCard->add_on_size_cost['total'] : '0'); ?></td>
                                                    <td><?php echo e($viewDesignCard && isset($viewDesignCard->add_on_size_cost['offered']) ? $viewDesignCard->add_on_size_cost['offered'] : '0'); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>

                                        <h5 class="font-weight-bold">Main</h5>
                                        <table class="table table-bordered text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th>Needle No</th>
                                                    <th>Pantone</th>
                                                    <th>Color</th>
                                                    <th>Shade</th>
                                                    <th>Denier</th>
                                                    <th>A</th>
                                                    <th>B</th>
                                                    <th>C</th>
                                                    <th>D</th>
                                                    <th>E</th>
                                                </tr>
                                            </thead>
                                            <tbody id="add_new_row">
                                                <?php $__empty_1 = true; $__currentLoopData = $viewDesignCard->main_needle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainNeedle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr id="inputFormRow">
                                                        <td><?php echo e($mainNeedle['needle_no'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['pantone'] ?? '-'); ?></td>
                                                        <td style="background:<?php echo e($mainNeedle['color'] ?? ''); ?>;"></td>
                                                        <td><?php echo e($mainNeedle['color_shade'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['denier'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['a1'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['b1'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['c1'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['d1'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['e1'] ?? '-'); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>

                                        <h5 class="font-weight-bold">Tab</h5>
                                        <table class="table table-bordered text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th>Needle No</th>
                                                    <th>Pantone</th>
                                                    <th>Color</th>
                                                    <th>Shade</th>
                                                    <th>Denier</th>
                                                    <th>A</th>
                                                    <th>B</th>
                                                    <th>C</th>
                                                    <th>D</th>
                                                    <th>E</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $viewDesignCard->tab_needle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tabNeedle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($tabNeedle['needle_no'] ?? '-'); ?></td>
                                                        <td><?php echo e($tabNeedle['pantone'] ?? '-'); ?></td>
                                                        <td style="background:<?php echo e($tabNeedle['color'] ?? ''); ?>;"></td>
                                                        <td><?php echo e($tabNeedle['color_shade'] ?? '-'); ?></td>
                                                        <td><?php echo e($tabNeedle['denier'] ?? '-'); ?></td>
                                                        <td><?php echo e($tabNeedle['a1'] ?? '-'); ?></td>
                                                        <td><?php echo e($tabNeedle['b1'] ?? '-'); ?></td>
                                                        <td><?php echo e($tabNeedle['c1'] ?? '-'); ?></td>
                                                        <td><?php echo e($tabNeedle['d1'] ?? '-'); ?></td>
                                                        <td><?php echo e($tabNeedle['e1'] ?? '-'); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>

                                        <h5 class="font-weight-bold">Size</h5>
                                        <table class="table table-bordered text-nowrap">
                                            <thead>
                                                <tr>
                                                    <th>Needle No</th>
                                                    <th>Pantone</th>
                                                    <th>Color</th>
                                                    <th>Shade</th>
                                                    <th>Denier</th>
                                                    <th>A</th>
                                                    <th>B</th>
                                                    <th>C</th>
                                                    <th>D</th>
                                                    <th>E</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $viewDesignCard->size_needle; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sizeNeedle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($sizeNeedle['needle_no'] ?? '-'); ?></td>
                                                        <td><?php echo e($mainNeedle['pantone'] ?? '-'); ?></td>
                                                        <td style="background:<?php echo e($sizeNeedle['color'] ?? ''); ?>;"></td>
                                                        <td><?php echo e($sizeNeedle['color_shade'] ?? '-'); ?></td>
                                                        <td><?php echo e($sizeNeedle['denier'] ?? '-'); ?></td>
                                                        <td><?php echo e($sizeNeedle['a1'] ?? '-'); ?></td>
                                                        <td><?php echo e($sizeNeedle['b1'] ?? '-'); ?></td>
                                                        <td><?php echo e($sizeNeedle['c1'] ?? '-'); ?></td>
                                                        <td><?php echo e($sizeNeedle['d1'] ?? '-'); ?></td>
                                                        <td><?php echo e($sizeNeedle['e1'] ?? '-'); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="col-3">
                                    <div class="form-group">
                                        <label>Front Image</label>
                                        <div class="object-fit-container"> 
                                           <?php if($viewDesignCard->front_image): ?> 
                                            <img class="object-fit-cover"  src="<?php echo e(asset('./designCards/'.$viewDesignCard->front_image)); ?>"/>
                                            <?php endif; ?>
                                        </div>
                                    </div> 
                                    <hr>
                                    <div class="form-group">
                                        <label>Back Image</label>
                                        <div class="object-fit-container">
                                            <?php if($viewDesignCard->back_image): ?>   
                                            <img class="object-fit-cover"  src="<?php echo e(asset('./designCards/'.$viewDesignCard->back_image)); ?>"/>
                                            <?php endif; ?>
                                        </div>
                                    </div> 
                                    <hr>
                                    <div class="form-group">
                                        <label>All View Image</label>
                                        <div class="object-fit-container">
                                             <?php if($viewDesignCard->all_view_image): ?>   
                                            <img class="object-fit-cover" src="<?php echo e(asset('./designCards/'.$viewDesignCard->all_view_image)); ?>" />
                                            <?php endif; ?>
                                        </div>
                                    </div> 
                                    <hr>
                                    <div class="form-group">
                                        <div class="mt-4">
                                            <label for="document_name">Design File</label>
                                            <?php if($viewDesignCard->design_file && count(json_decode($viewDesignCard->design_file)) > 0): ?>
                                                <?php $__currentLoopData = json_decode($viewDesignCard->design_file); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designFile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <p class="mt-1">
                                                    <a href="<?php echo e(asset('./cardsDocuments/'.$viewDesignCard->id.'/'.$designFile)); ?>" class="text-success" download><i class="fas fa-download mr-2"></i> <?php echo e($designFile); ?></a>
                                                </p>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div> 
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha384-vk5WoKIaW/vJyUAd9n/wmopsmNhiy+L2Z+SBxGYnUkunIxVxAv/UtMOhba/xskxh" crossorigin="anonymous"></script>
    <script type="text/javascript">
        $("#print").on('click', function () {
            // $("#print_area").show();
            window.print();
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp_7.4\htdocs\personal_project\new\carddesign.yenjoy.in\resources\views/woven/show.blade.php ENDPATH**/ ?>