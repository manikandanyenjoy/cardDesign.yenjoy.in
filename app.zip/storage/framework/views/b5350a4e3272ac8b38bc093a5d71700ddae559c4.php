<?php $__env->startSection('title', 'loom'); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="row mb-2">
        <div class="col-sm-6">
            <h1><?php echo e(__('loom - ') . $loom->loom_name); ?></h1>
        </div>
        <div class="col-sm-6">
            <a href="<?php echo e(route('looms.index')); ?>" class="btn bg-gradient-primary float-right">Back</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="offset-md-3 col-md-6">
                    <div class="card card-primary">
                        <div class="card-header">
                            <h3 class="card-title">loom</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <table class="table table-bordered table-sm">
                                <tbody>
                                    <tr>
                                        <td><strong><?php echo e(__('Loom Name')); ?></strong></td>
                                        <td><?php echo e($loom->loom_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Weaving')); ?></strong></td>
                                        <td><?php echo e($loom->weaving_width_Meter); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Sections')); ?></strong></td>
                                        <td><?php echo e($loom->sections); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Speed')); ?></strong></td>
                                        
                                    <td><?php echo e($loom->speed); ?></td>
                                    </tr>
                                    <tr>
                                        <td><strong><?php echo e(__('Year')); ?></strong></td>
                                        <td><?php echo e($loom->year); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td><strong><?php echo e(__('Notes')); ?></strong></td>
                                        <td><?php echo e($loom->notes); ?></td>
                                    </tr>
                                   
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <!-- /.card -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/yenjoyin/carddesign.yenjoy.in/resources/views/looms/show.blade.php ENDPATH**/ ?>