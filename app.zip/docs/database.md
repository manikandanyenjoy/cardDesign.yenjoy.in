###Tables

- Bidding
- BodyType
- Buyer
- DriveType
- Favourite
- FuelType
- LandingBanner
- Location
- Product --> Vechicle
- ProductBrand --> Make
- ProductCategory --> Model
- ProductImage --> Vechicle Images (interior, exterior, listing)
- ProductYear
- Seller
- SubscriptionPayment
- SubscriptionPlan
- Transmission
- User
