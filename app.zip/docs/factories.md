#Factories

###Admin
```php
\App\Models\User::factory(50)->create();
```

###Buyers
```php
\App\Models\Buyer::factory(50)->create();
```

###Sellers
```php
\App\Models\Seller::factory(50)->create();
```
